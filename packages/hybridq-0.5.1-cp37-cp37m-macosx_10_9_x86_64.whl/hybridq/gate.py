"""
Author: Salvatore Mandra (salvatore.mandra@nasa.gov)

Copyright © 2021, United States Government, as represented by the Administrator
of the National Aeronautics and Space Administration. All rights reserved.

The HybridQ: A Hybrid Simulator for Quantum Circuits platform is licensed under
the Apache License, Version 2.0 (the "License"); you may not use this file
except in compliance with the License. You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from __future__ import annotations
from opt_einsum import get_symbol, contract
from copy import copy, deepcopy
from scipy.linalg import expm, sqrtm, fractional_matrix_power
from hybridq.utils import sort, argsort, svd
from warnings import warn
import numpy as np

_available_gates = {
    'I': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: np.array(np.eye(2))
    },
    'U3': {
        'n_qubits':
            1,
        'n_params':
            3,
        'U_gen':
            lambda t, p, l: np.array(
                [[np.cos(t / 2), -np.exp(1j * l) * np.sin(t / 2)],
                 [
                     np.exp(1j * p) * np.sin(t / 2),
                     np.exp(1j * (l + p)) * np.cos(t / 2)
                 ]])
    },
    'H': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: np.array([[1, 1], [1, -1]]) / np.sqrt(2)
    },
    'X': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: np.array([[0, 1], [1, 0]])
    },
    'Y': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: np.array([[0, -1j], [1j, 0]])
    },
    'Z': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: np.array([[1, 0], [0, -1]])
    },
    'P': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: np.array([[1, 0], [0, 1j]])
    },
    'T': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]])
    },
    'SQRT_X': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: sqrtm(np.array([[0, 1], [1, 0]]))
    },
    'SQRT_Y': {
        'n_qubits': 1,
        'n_params': 0,
        'U_gen': lambda: sqrtm(np.array([[0, -1j], [1j, 0]]))
    },
    'RX': {
        'n_qubits':
            1,
        'n_params':
            1,
        'U_gen':
            lambda r: np.array(expm(-1j * np.array([[0, 1], [1, 0]]) * r / 2))
    },
    'RY': {
        'n_qubits':
            1,
        'n_params':
            1,
        'U_gen':
            lambda r: np.array(expm(-1j * np.array([[0, -1j], [1j, 0]]) * r / 2)
                              )
    },
    'RZ': {
        'n_qubits':
            1,
        'n_params':
            1,
        'U_gen':
            lambda r: np.array(expm(-1j * np.array([[1, 0], [0, -1]]) * r / 2))
    },
    'R_PI_2': {
        'n_qubits':
            1,
        'n_params':
            1,
        'U_gen':
            lambda phi: np.array([[1, -1j * np.exp(-1j * phi)],
                                  [-1j * np.exp(1j * phi), 1]]) / np.sqrt(2)
    },
    'CPHASE': {
        'n_qubits':
            2,
        'n_params':
            1,
        'U_gen':
            lambda p: np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0],
                                [0, 0, 0, np.exp(1j * p)]])
    },
    'CX': {
        'n_qubits':
            2,
        'n_params':
            0,
        'U_gen':
            lambda: np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1],
                              [0, 0, 1, 0]])
    },
    'CZ': {
        'n_qubits':
            2,
        'n_params':
            0,
        'U_gen':
            lambda: np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0],
                              [0, 0, 0, -1]])
    },
    'ZZ': {
        'n_qubits':
            2,
        'n_params':
            0,
        'U_gen':
            lambda: np.array([[1, 0, 0, 0], [0, -1, 0, 0], [0, 0, -1, 0],
                              [0, 0, 0, 1]])
    },
    'FSIM': {
        'n_qubits':
            2,
        'n_params':
            2,
        'U_gen':
            lambda t, p: np.array(
                [[1, 0, 0, 0], [0, np.cos(t), -1j * np.sin(t), 0],
                 [0, -1j * np.sin(t), np.cos(t), 0], [0, 0, 0,
                                                      np.exp(-1j * p)]])
    },
    'SWAP': {
        'n_qubits':
            2,
        'n_params':
            0,
        'U_gen':
            lambda: np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0],
                              [0, 0, 0, 1]])
    },
    'ISWAP': {
        'n_qubits':
            2,
        'n_params':
            0,
        'U_gen':
            lambda: np.array([[1, 0, 0, 0], [0, 0, 1j, 0], [0, 1j, 0, 0],
                              [0, 0, 0, 1]])
    },
    'SQRT_ISWAP': {
        'n_qubits':
            2,
        'n_params':
            0,
        'U_gen':
            lambda: sqrtm(
                np.array([[1, 0, 0, 0], [0, 0, 1j, 0], [0, 1j, 0, 0],
                          [0, 0, 0, 1]]))
    },
}

_gate_aliases = {
    'ID': 'I',
    'S': 'P',
    'Z_1_2': 'P',
    'SQRT_Z': 'P',
    'CNOT': 'CX',
    'X_1_2': 'SQRT_X',
    'Y_1_2': 'SQRT_Y',
    'FS': 'FSIM',
}

_clifford_gates = [
    'I',
    'H',
    'X',
    'Y',
    'Z',
    'P',
    'SQRT_X',
    'SQRT_Y',
    'CX',
    'CZ',
    'ZZ',
    'SWAP',
    'ISWAP',
]


class Gate(object):
    """
    Class representing a single gate.

    Attributes
    ----------
    name: str
        Name of `Gate`.
    qubits: list[any], optional
        List of qubits `Gate` is acting on.
    params: list[any], optional
        List of parameters to define `Gate`.
    power: float, optional
        The power the unitary matrix of `Gate` is elevated to.
    tags: dict[any, any], optional
        Dictionary of tags.
    U: list[list[any]], optional
        If `name` is `MATRIX`, its unitary matrix must be provided using `U`.
    check_unitary: bool, optional
        If `U` is provided, check that `U` is unitary. Otherwise, raise
        `ValueError`.

    Example
    -------
    >>> g = Gate('RX', qubits=[1], params=[3.2])**3.4
    >>> g.unitary()
    array([[6.65087527e-01+1.10596489e-16j, 6.50125829e-17+7.46765413e-01j],
           [9.71433860e-18+7.46765413e-01j, 6.65087527e-01+1.05739319e-16j]])

    It is also possible to specify gates by using their matrix representation:
    >>> g = Gate('MATRIX', qubits=[1], U=[[0,-1j], [1j, 0]])
    >>> g
    Gate(name=MATRIX, qubits=[1], U=np.array(shape=(2, 2), dtype=complex128))
    >>> g.isclose(Gate('Y')) # Acting on different qubits
    False
    >>> g.isclose(Gate('Y', qubits=[1])) # Acting on the same qubits
    True
    """

    def __setattr__(self, *args) -> None:
        raise ValueError("Operation not permitted.")

    def __delattr__(self, *args) -> None:
        raise ValueError("Operation not permitted.")

    def __init__(self,
                 name: str,
                 qubits: iter[any] = None,
                 params: iter[any] = None,
                 power: any = 1,
                 tags: dict[any, any] = None,
                 U: list[list[any]] = None,
                 check_unitary: bool = False) -> None:

        # Convert name to upper
        name = name.upper()

        # Check if name is an alias
        if name in _gate_aliases:
            warn(
                f"'{name}' is an alias for '{_gate_aliases[name]}'. Using Gate(name='{_gate_aliases[name]}')."
            )
            name = _gate_aliases[name]

        # Check if name is in _available_qubits
        if name not in _available_gates and name != 'MATRIX':
            raise ValueError(f"Gate(name='{name}') not available.")

        # If MATRIX, the unitary matrix must be provided
        if name == 'MATRIX':
            # Check that matrix representation is present
            if U is None:
                raise ValueError("Gate(name='MATRIX') requires 'U'.")

            # Assign U ..
            object.__setattr__(self, 'U', np.array(U))

            # .. and make it read-only
            self.U.flags['WRITEABLE'] = False

            # Check shape
            _x, _y = self.U.shape
            if _x != _y or not np.isclose(np.log2(_x), int(np.log2(_x))):
                raise ValueError(
                    f"'U' must be a quadratic matrix of shape (2^n, 2^n).")

            # Check if unitary
            if check_unitary:
                if not np.allclose(self.U.dot(self.U.T.conj()),
                                   np.eye(len(self.U))) or not np.allclose(
                                       np.eye(len(self.U)),
                                       self.U.dot(self.U.T.conj())):
                    raise ValueError(f"'U' must be a unitary matrix.")

        # Set gate
        object.__setattr__(self, 'name', str(name))

        # Update qubits
        self._on(qubits)

        # Update params
        self._set_params(params)

        # Set power
        self._set_power(power)

        # Update tags
        self._set_tags(tags)

    def __str__(self) -> str:
        """
        Return string representation of Gate.
        """

        _str = f"Gate(name='{self.name}'"
        if hasattr(self, 'qubits'):
            _str += f", qubits={self.qubits}"
        if hasattr(self, 'params') and len(self.params):
            _str += f", params={self.params}"
        if self.name == 'MATRIX':
            _str += f', U=np.array(shape={self.U.shape}, dtype={str(self.U.dtype)})'
        if hasattr(self, 'tags') and self.tags:
            _str += f', tags={self.tags}'
        _str += ')'
        if self.power != 1:
            _str += f'**{self.power}'
        return _str

    def __repr__(self) -> str:
        """
        Return string representation of Gate.
        """

        return self.__str__()

    def __neq__(self, g: Gate) -> bool:
        return not (self.__eq__(g))

    def __eq__(self, g: Gate) -> bool:
        """
        Two gates are equal if everything matches (including tags).
        """

        # If keys don't match, the gates differ
        if self.__dict__.keys() != g.__dict__.keys():

            return False

        else:

            # Check key by key
            for k, v in self.__dict__.items():

                # If np.ndarray, return False if at least one element differs
                if type(v) == np.ndarray:
                    if np.any(v != g.__dict__[k]):
                        return False

                # Otherwise, return False if the two values are not equivalent
                else:
                    if v != g.__dict__[k]:
                        return False

            return True

    def isclose(self, gate: Gate, atol: float = 1e-8) -> bool:
        """
        Determine if the unitary matrix of `gate` is close within an absolute
        tollerance. If the gates are acting on a different set of qubits,
        `isclose` will return `False`.

        Parameters
        ----------
        gate: Gate
            Gate to compare with.
        atol: float, optional
            Absolute tollerance.

        Returns
        -------
        bool
            `True` if the two gates are close withing the given absolute
            tollerance, otherwise `False`.

        Example
        -------
        >>> Gate('X', qubits=[1]).isclose(Gate('Y', qubits=[1]))
        False
        >>> Gate('Y', qubits=[1]).isclose(Gate('Y', qubits=[2]))
        True
        >>> Gate('RX', qubits=[1]).isclose(Gate('RX', qubits=[1]))
        True
        >>> Gate('RX', qubits=[1], params=[1.23]).isclose(Gate('RX', qubits=[1]))
        False
        """

        if hasattr(self, 'qubits') == hasattr(gate, 'qubits'):

            # The gates differ if they act on a different set of qubits
            if hasattr(self,
                       'qubits') and sort(self.qubits) != sort(gate.qubits):
                return False

            # If the gates have the same name, we can avoid to create unitaries if there is a match
            if self.name == gate.name and self.name != 'MATRIX' and np.isclose(
                    float(self.power), float(gate.power), atol=atol):
                if not hasattr(self, 'qubits') or self.qubits == gate.qubits:
                    if hasattr(self, 'params') == hasattr(gate, 'params'):
                        if not hasattr(self, 'params') or np.allclose(
                            [float(p) for p in self.params],
                            [float(p) for p in gate.params],
                                atol=atol):
                            return True

            # Get unitaries
            _U1 = self.unitary() if self.name == 'MATRIX' or _available_gates[
                self.name]['n_params'] == 0 or hasattr(self, 'params') else None
            _U2 = gate.unitary(
                order=self.qubits if hasattr(self, 'qubits') else None
            ) if gate.name == 'MATRIX' or _available_gates[
                gate.name]['n_params'] == 0 or hasattr(gate, 'params') else None

            # If either unitary does not exist, the two gates differ
            if _U1 is None or _U2 is None:
                return False
            else:
                return np.allclose(_U1, _U2, atol=atol)

        else:

            return False

    def __pow__(self, p: any) -> Gate:
        """
        Return `Gate`**p.
        """

        return self.set_power(self.power * p, inplace=False)

    def _inv(self) -> None:
        """
        Modify `Gate` to its inverse.
        """

        self.inv(inplace=True)

    def inv(self, *, inplace: bool = False) -> Gate:
        """
        Return inverse of `Gate`. If `inplace` is `True`, `Gate` is modified in place.

        Parameters
        ----------
        inplace: bool, optional
            If `True`, Gate is modified in place. Otherwise, a new
            `Gate` is returned.

        Returns
        -------
        Gate
            Inverse of `Gate`. If `True`, `Gate` is modified in place.

        Example
        -------
        >>> Gate('P')
        Gate(name=P)
        >>> Gate('P').inv()
        Gate(name=P)**-1
        >>> Gate('P').unitary().dot(Gate('P').inv().unitary())
        array([[1.+0.j, 0.+0.j],
               [0.+0.j, 1.+0.j]])
        """

        return self.set_power(self.power * -1, inplace=inplace)

    def _on(self, qubits: iter[any]) -> None:
        """
        Set `qubits` to `Gate`.
        """

        self.on(qubits, inplace=True)

    def on(self, qubits: iter[any], *, inplace: bool = False) -> Gate:
        """
        Return `Gate` applied to `qubits`. If `inplace` is `True`, `Gate` is
        modified in place.

        Parameters
        ----------
        qubits: iter[any]
            Qubits the new Gate will act on.
        inplace: bool, optional
            If `True`, `Gate` is modified in place. Otherwise, a new `Gate`
            is returned.

        Returns
        -------
        Gate
            New `Gate` acting on `qubits`. If `inplace` is `True`, `Gate` is
            modified in place.

        Example
        -------
        >>> Gate('H')
        Gate(name=H)
        >>> Gate('H').on([3])
        Gate(name=H, qubits=[3])
        """

        # Convert qubits to list
        if qubits is not None:
            qubits = list(qubits)

        # Make a copy if needed
        if inplace:
            _g = self
        else:
            _g = deepcopy(self)

        # If qubits = [], just reset qubits
        if qubits:

            # Check that there are no repeated qubits
            if len(qubits) != len(set(qubits)):
                raise ValueError(f"Repeated qubits are not allowed.")

            # Check that it matches the correct number
            if self.name != 'MATRIX' and _available_gates[
                    self.name]['n_qubits'] != len(qubits):
                raise ValueError(
                    f"Gate(name='{self.name}') requires {_available_gates[self.name]['n_qubits']} qubits."
                )
            elif self.name == 'MATRIX':
                if len(self.U) != 2**len(qubits):
                    raise ValueError(
                        f"Gate(name='{self.name}') requires {int(np.log2(len(self.U)))} qubits."
                    )

            # Assign qubits
            object.__setattr__(_g, 'qubits', qubits)

        elif hasattr(self, 'qubits'):

            # Remove qubits
            object.__delattr__(_g, 'qubits')

        return _g

    def _set_params(self, params: iter[any]) -> None:
        """
        Set `params` to `Gate`.
        """

        self.set_params(params, inplace=True)

    def set_params(self, params: iter[any], *, inplace: bool = False) -> Gate:
        """
        Return `Gate` with given `params`. If `inplace` is `True`, `Gate` is
        modified in place.

        Parameters
        ----------
        params: iter[any]
            Parameters used to define the new Gate.
        inplace: bool, optional
            If `True`, `Gate` is modified in place. Otherwise, a new `Gate` is
            returned.

        Returns
        -------
        Gate
            New `Gate` with `params`. If `inplace` is `True`, `Gate` is modified
            in place.

        Example
        -------
        >>> Gate('RX')
        Gate(name=RX)
        >>> Gate('RX').unitary()
        ValueError: Gate(name='RX') requires 1 parameters.
        >>> Gate('H').set_params([1.23]).unitary()
        array([[0.81677345+0.j        , 0.        -0.57695852j],
               [0.        -0.57695852j, 0.81677345+0.j        ]])
        """

        # Convert params to list
        if params is not None:
            params = list(params)

        # Make a copy if needed
        if inplace:
            _g = self
        else:
            _g = deepcopy(self)

        # If params = [], just reset params
        if params:

            # Check that it matches the correct number
            if self.name != 'MATRIX' and _available_gates[
                    self.name]['n_params'] != len(params):
                raise ValueError(
                    f"Gate(name='{self.name}') requires {_available_gates[self.name]['n_params']} parameters."
                )
            elif self.name == 'MATRIX':
                raise ValueError(
                    f"Gate(name='{self.name}') does not accept parameters.")

            # Assign params
            object.__setattr__(_g, 'params', params)

        elif hasattr(self, 'params'):

            # Remove params
            object.__delattr__(_g, 'params')

        return _g

    def _set_tags(self, tags: dict[any, any]) -> None:
        """
        Set `tags` to `Gate`.
        """

        self.set_tags(tags, inplace=True)

    def set_tags(self, tags: dict[any, any], *, inplace: bool = False) -> Gate:
        """
        Return `Gate` with given `tags`. All previous tags are removed and
        substituted with `tags`. If `inplace` is `True`, `Gate` is modified in
        place.

        Parameters
        ----------
        tags: dict[any, any]
            Parameters used to define the new `Gate`.
        inplace: bool, optional
            If `True`, `Gate` is modified in place. Otherwise, a new `Gate` is
            returned.

        Returns
        -------
        Gate
            New `Gate` with `tags`. If `inplace` is `True`, `Gate` is modified in place.

        Example
        -------
        >>> Gate('T')
        Gate(name=T)
        >>> Gate('T').set_tags({1: 1, '2': '2', (1, 2): 2.23})
        Gate(name=T, tags={1: 1, '2': '2', (1, 2): 2.23})
        >>> Gate('T').set_tags({1: 1, '2': '2', (1, 2): 2.23}).set_tags({42: 42})
        Gate(name=T, tags={42: 42})
        """

        # Convert tags to dict
        if tags is not None:
            tags = {**tags}

        # Make a copy if needed
        if inplace:
            _g = self
        else:
            _g = deepcopy(self)

        # If tags = {}, just reset tags
        if tags:

            # Assign tags
            object.__setattr__(_g, 'tags', tags)

        elif hasattr(self, 'tags'):

            # Remove params
            object.__delattr__(_g, 'tags')

        return _g

    def _update_tags(self, *args, **kwargs) -> None:
        """
        Update `Gate`'s `tags`.
        """

        self.update_tags(*args, **kwargs, inplace=True)

    def update_tags(self, *args, inplace: bool = False, **kwargs) -> Gate:
        """
        Return `Gate` with updated tags. If `inplace` is `True`, `Gate` is
        modified in place.

        Parameters
        ----------
        inplace: bool, optional
            If `True`, `Gate` is modified in place. Otherwise, a new `Gate` is
            returned.

        Returns
        -------
        Gate
            New `Gate` with updated tags. If `inplace` is `True`, `Gate` is
            modified in place.

        Example
        -------
        >>> Gate('T')
        Gate(name=T)
        >>> g = Gate('T').set_tags({1: 1, '2': '2', (1, 2): 2.23})
        >>> g
        Gate(name=T, tags={1: 1, '2': '2', (1, 2): 2.23})
        >>> g.update_tags({1: 3})
        Gate(name=T, tags={1: 3, '2': '2', (1, 2): 2.23})
        >>> g.update_tags([(1, -1), (42, 42)])
        Gate(name=T, tags={1: -1, '2': '2', (1, 2): 2.23, 42: 42})
        """

        # Make a copy if needed
        if inplace:
            _g = self
        else:
            _g = deepcopy(self)

        if not hasattr(_g, 'tags'):
            object.__setattr__(_g, 'tags', dict())

        # Update tags
        _g.tags.update(*args, **kwargs)

        return _g

    def _remove_tags(self, keys: iter[any]) -> None:
        """
        Remove tags matching `keys`.
        """

        self.remove_tags(keys, inplace=True)

    def remove_tags(self, keys: iter[any], *, inplace: bool = False) -> Gate:
        """
        Return `Gate` with removed tags matching `keys`. If `inplace` is `True`,
        `Gate` is modified in place.

        Parameters
        ----------
        keys: iter[any]
            Keys to remove from tags.
        inplace: bool, optional
            If `True`, `Gate` is modified in place. Otherwise, a new `Gate` is
            returned.

        Returns
        -------
        Gate
            New `Gate` with `keys` in tags removed. If `inplace` is `True`,
            `Gate` is modified in place.

        Example
        -------
        >>> Gate('T')
        Gate(name=T)
        >>> g = Gate('T').set_tags({1: 1, '2': '2', (1, 2): 2.23})
        >>> g
        Gate(name=T, tags={1: 1, '2': '2', (1, 2): 2.23})
        >>> g.remove_tags(('2', (1, 2)))
        Gate(name=T, tags={'2': '2'})
        """

        # Make a copy if needed
        if inplace:
            _g = self
        else:
            _g = deepcopy(self)

        if hasattr(_g, 'tags'):

            # Convert to set
            keys = set(keys)

            # Remove tags
            _g._set_tags({k: v for k, v in _g.tags.items() if k not in keys})

        return _g

    def _remove_tag(self, key: any) -> None:
        """
        Remove tag matching `key`.
        """

        self.remove_tag(key, inplace=True)

    def remove_tag(self, key: any, *, inplace: bool = False) -> Gate:
        """
        Return `Gate` with removed tag mathcing `key`. If `inplace` is `True`,
        `Gate` is modified in place.

        Parameters
        ----------
        key: any
            Key to remove from tags.
        inplace: bool, optional
            If `True`, `Gate` is modified in place. Otherwise, a new `Gate` is
            returned.

        Returns
        -------
        Gate
            New `Gate` with `key` in tags removed. If `inplace` is `True`,
            `Gate` is modified in place.

        Example
        -------
        >>> Gate('T')
        Gate(name=T)
        >>> g = Gate('T').set_tags({1: 1, '2': '2', (1, 2): 2.23})
        >>> g
        Gate(name=T, tags={1: 1, '2': '2', (1, 2): 2.23})
        >>> g.remove_tag('2')
        Gate(name=T, tags={1: 1, (1, 2): 2.23})
        """

        return self.remove_tags([key], inplace=inplace)

    def _set_power(self, power: any) -> None:
        """
        Set `power` to `Gate`.
        """

        self.set_power(power, inplace=True)

    def set_power(self, power: any, *, inplace: bool = False) -> Gate:
        """
        Return `Gate` to the given `power`. If `inplace` is `True`, `Gate` is
        modified in place.

        Parameters
        ----------
        power: any
            Power to elevate `Gate`.
        inplace: bool, optional
            If `True`, `Gate` is modified in place. Otherwise, a new `Gate` is
            returned.

        Returns
        -------
        Gate
            New `Gate` to the given `power`. If `inplace` is `True`, `Gate` is
            modified in place.

        Example
        -------
        >>> Gate('T').unitary()
        array([[1.        +0.j        , 0.        +0.j        ],
               [0.        +0.j        , 0.70710678+0.70710678j]])
        >>> Gate('T').set_power(3.1416).unitary()
        array([[ 1.        +0.j        ,  0.        +0.j        ],
               [ 0.        +0.j        , -0.78121549+0.62426145j]])
        """

        # Make a copy if needed
        if inplace:
            _g = self
        else:
            _g = deepcopy(self)

        # Assign qubits
        object.__setattr__(_g, 'power', power)

        return _g

    def unitary(self, order: iter[any] = None) -> np.ndarray:
        """
        Return unitary matrix representing `Gate`. If `order` is provided, the
        given order of qubits is used to output the unitary matrix.

        Parameters
        ----------
        order: iter[any]
            Order of qubits used to output the unitary matrix.

        Returns
        -------
        array_like
            Unitary matrix representing `Gate`.

        Example
        -------
        >>> Gate('CX', qubits=[1, 0]).unitary()
        array([[1, 0, 0, 0],
               [0, 1, 0, 0],
               [0, 0, 0, 1],
               [0, 0, 1, 0]])

        The order of qubits is `[1, 0]`. On the contrary:
        >>> Gate('CX', qubits=[1, 0]).unitary(order=[0, 1])
        array([[1, 0, 0, 0],
               [0, 0, 0, 1],
               [0, 0, 1, 0],
               [0, 1, 0, 0]])

        outputs a unitary matrix with the qubits order being if `[0, 1]`.
        """

        # Check if params are missing
        if self.name in _available_gates and _available_gates[
                self.name]['n_params']:
            if not hasattr(self, 'params') or len(
                    self.params) != _available_gates[self.name]['n_params']:
                raise ValueError(
                    f"Gate(name='{self.name}') requires {_available_gates[self.name]['n_params']} parameters."
                )

        # Covert order to list
        if order is not None:
            order = list(order)

        # Order is allowed only if gate.qubits are specified
        if order and (not hasattr(self, 'qubits') or
                      sort(order) != sort(self.qubits)):
            raise ValueError("'order' is not a permutation of 'gate.qubits'.")

        # Check if the unitary generator is available
        if self.name in _available_gates and 'U_gen' in _available_gates[
                self.name]:
            _U = _available_gates[self.name]['U_gen'](
                *([float(p)
                   for p in self.params] if hasattr(self, 'params') else []))
        elif self.name == 'MATRIX':
            _U = self.U
        else:
            raise ValueError(f"Not supported for Gate(name='{self.name}')")

        # Reorder matrix in case qubits are out-of-order
        if order and order != self.qubits:
            # Get number of qubits
            n_qubits = len(self.qubits)
            # Transpose
            _U = np.reshape(
                np.transpose(np.reshape(_U, (2,) * (2 * n_qubits)),
                             [self.qubits.index(q) for q in order] +
                             [n_qubits + self.qubits.index(q) for q in order]),
                (2**n_qubits, 2**n_qubits))

        # Apply power
        if self.power == 1:
            pass
        elif self.power == -1:
            _U = _U.T.conj()
        else:
            _U = fractional_matrix_power(_U, float(self.power))

        return _U

    def commutes_with(self, gate: Gate, atol: float = 1e-8) -> bool:
        """
        Return `True` if the calling gate commutes with `gate`.

        Parameters
        ----------
        gate: Gate
            Gate to check commutation with.
        atol: float
            Absolute tollerance.

        Returns
        -------
        bool
            `True` if the calling gate commutes with `gate`, otherwise `False`.
        """

        # Get shared qubits
        shared_qubits = sort(set(self.qubits).intersection(gate.qubits))

        # If no qubits are shared, the gates definitely commute
        if not shared_qubits:
            return True

        # Get decompositions
        _, U1, _ = svd(self.unitary(),
                       [self.qubits.index(q) for q in shared_qubits],
                       atol=atol)
        _, U2, _ = svd(gate.unitary(),
                       [gate.qubits.index(q) for q in shared_qubits],
                       atol=atol)

        return np.allclose([a @ b - b @ a for a in U1 for b in U2],
                           0,
                           atol=atol)

    def isvirtual(self) -> bool:
        """
        Return `True` if `Gate` is virtual and `False` otherwise. `Gate` is virtual if
        at least one of the following statement is true:

        - `Gate` is not applied to any qubits,
        - `Gate`'s parameters are not specified (if required) or not convertible
          to `float`,
        - `Gate`'s power is not convertible to `float`.

        Returns
        -------
        bool
            `True` if `Gate` is virtual, `False` otherwise.

        Example
        -------
        >>> Gate('RX').isvirtual()
        True
        >>> Gate('RX', qubits=[1]).isvirtual()
        True
        >>> Gate('RX', qubits=[1], params=[lambda x: x**2]).isvirtual()
        True
        >>> Gate('RX', qubits=[1], params=[3.2]).isvirtual()
        False

        If only the qubits are not specified, it is still possible to get the
        unitary matrix representing `Gate`, even if `Gate` is virtual:
        >>> Gate('RX').isvirtual()
        True
        >>> Gate('RX').unitary()
        ValueError: Gate(name='RX') requires 1 parameters.
        >>> Gate('RX', params=[3.2]).isvirtual()
        True
        >>> Gate('RX', params=[3.2]).unitary()
        array([[-0.02919952-0.j       ,  0.        -0.9995736j],
               [ 0.        -0.9995736j, -0.02919952-0.j       ]])
        """

        # Check if qubits have been assigned. If not, gate is virtual
        if not hasattr(self, 'qubits'):
            return True

        # Check if power is convertible to float. If not, gate is virtual
        try:
            float(self.power)
        except:
            return True

        # If gate.name != 'MATRIX', check if all parameters are convertible to float.
        # If not, gate is virtual
        if self.name != 'MATRIX' and _available_gates[
                self.name]['n_params'] != 0:
            if hasattr(self, 'params'):
                try:
                    [float(p) for p in self.params]
                except:
                    return True
            else:
                return True

        return False

"""
Author: Salvatore Mandra (salvatore.mandra@nasa.gov)

Copyright © 2021, United States Government, as represented by the Administrator
of the National Aeronautics and Space Administration. All rights reserved.

The HybridQ: A Hybrid Simulator for Quantum Circuits platform is licensed under
the Apache License, Version 2.0 (the "License"); you may not use this file
except in compliance with the License. You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from __future__ import annotations
from tempfile import TemporaryDirectory
from cffi import FFI
import numpy as np
import ctypes
import sys

# Available types
_types = {
    np.dtype('float32'): ['float', ctypes.c_float],
    np.dtype('float64'): ['double', ctypes.c_double],
    np.dtype('int32'): ['int', ctypes.c_int],
    np.dtype('int64'): ['long', ctypes.c_long],
    np.dtype('uint32'): ['unsigned int', ctypes.c_uint],
    np.dtype('uint64'): ['unsigned long', ctypes.c_ulong],
}

# Initialize builder
_ffibuilder = FFI()

# Define header
_ffibuilder.cdef(''.join(
    f'void *allocate_{t.replace(" ", "_")}(unsigned int size, unsigned int alignment);'
    for t, _ in _types.values()) + "void deallocate(void *array);")

# Define source
_ffibuilder.set_source(
    "_aligned_array", ''.join(f"""
void *allocate_{t.replace(" ", "_")}(unsigned int size, unsigned int alignment) {{
        void *array;
        if (posix_memalign(&array, alignment, size * sizeof({t})))
            array = NULL;
        return array;
}}
""" for t, _ in _types.values()) + """
    void deallocate(void *array) {
        if (array != NULL)
            free(array);
    }
""")

# Get temporary folder
_build_dir = TemporaryDirectory()

# Compile code
_ffibuilder.compile(tmpdir=_build_dir.name)

# Import library
sys.path.append(_build_dir.name)
import _aligned_array.lib as _lib


class _iterator(object):

    def __init__(self, ref: list[any], size: int) -> None:
        self._n = 0
        self._size = size
        self._ref = ref

    def __next__(self) -> any:
        self._n += 1
        if self._n <= self._size:
            return self._ref[self._n - 1]
        else:
            raise StopIteration


class aligned_array(object):

    def __init__(self,
                 size: int,
                 *,
                 alignment: int = 16,
                 dtype: any = 'float') -> None:

        # Assign properties
        self._size = size
        self._alignment = alignment
        self._dtype = np.dtype(dtype)
        self._c_type = _types[self._dtype]

        # Allocate space
        self._ptr = _ffibuilder.cast(
            f'{self._c_type[0]} *',
            _lib.__dict__[f'allocate_{self._c_type[0].replace(" ", "_")}'](
                size, alignment))

        # Check pointer is not NULL
        if self._ptr == _ffibuilder.NULL:
            raise ValueError('Unable to allocate memory.')

        # Get c-pointer
        self._c_ptr = self.buffer().ctypes.data_as(
            ctypes.POINTER(self._c_type[1]))

    @property
    def size(self) -> int:
        return self._size

    @property
    def alignment(self) -> int:
        return self._alignment

    @property
    def c_type(self) -> str:
        return self._c_type[0]

    @property
    def c_ptr(self):
        return self._c_ptr

    @property
    def dtype(self) -> np.dtype:
        return self._dtype

    def tolist(self) -> list:
        return self[:]

    def buffer(self):
        # Return buffer
        return np.frombuffer(_ffibuilder.buffer(self._ptr, self.dtype.itemsize *
                                                self.size),
                             dtype=self.dtype)

    def isaligned(self, alignment: int):
        # True if pointer is properly aligned
        return not (self.ptr % alignment)

    def __str__(self) -> str:
        _str = 'aligned_array('
        if self.size <= 10:
            _str += ', '.join(f'{round(self[i], 5)}' for i in range(self.size))
        else:
            _str += ', '.join(f'{round(self[i], 5)}' for i in range(5))
            _str += ', ...,'
            _str += ', '.join(
                f'{round(self[self.size - 5 + i], 5)}' for i in range(5))
        _str += f", dtype='{self.dtype}', alignment={self.alignment})"
        return _str

    def __repr__(self) -> str:
        return str(self)

    def __len__(self) -> str:
        return self.size

    def __iter__(self) -> int:
        return _iterator(self, self.size)

    def __getitem__(self, key: any) -> float:
        if type(key) == int:
            return self._ptr[key if key >= 0 else self.size + key]
        elif type(key) == slice:
            _start = (key.start if key.start >= 0 else self.size +
                      key.start) if key.start else 0
            _stop = (key.stop if key.stop >= 0 else self.size +
                     key.stop) if key.stop else self.size
            return [
                self[i]
                for i in range(_start, _stop, key.step if key.step else 1)
            ]
        else:
            raise ValueError()

    def __setitem__(self, key: int, value: any):
        if type(key) == int:
            self._ptr[key if key >= 0 else self.size + key] = value
        elif type(key) == slice:
            _start = (key.start if key.start >= 0 else self.size +
                      key.start) if key.start else 0
            _stop = (key.stop if key.stop >= 0 else self.size +
                     key.stop) if key.stop else self.size
            for _i, _j in enumerate(
                    range(_start, _stop, key.step if key.step else 1)):
                self[_j] = value[_i]
        else:
            raise ValueError()

    def __del__(self) -> None:
        # Free memory
        _lib.deallocate(_ffibuilder.cast('void *', self._ptr))

        # Make the array unusable
        self._ptr = None
        self._dtype = None
        self._c_type = None
        self._size = 0

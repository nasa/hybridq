"""
Author: Salvatore Mandra (salvatore.mandra@nasa.gov)

Copyright © 2021, United States Government, as represented by the Administrator
of the National Aeronautics and Space Administration. All rights reserved.

The HybridQ: A Hybrid Simulator for Quantum Circuits platform is licensed under
the Apache License, Version 2.0 (the "License"); you may not use this file
except in compliance with the License. You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from __future__ import annotations
from hybridq.gate import Gate, _available_gates, _clifford_gates
from hybridq.circuit import Circuit
import numpy as np


def get_random_gate(randomize_power: bool = True,
                    use_clifford_only: bool = False):
    """
  Generate random gate.
  """
    gate_name = np.random.choice(
        _clifford_gates if use_clifford_only else list(_available_gates))
    params = np.random.random(size=_available_gates[gate_name]['n_params'])
    power = 2 * np.random.random() - 1 if randomize_power else 1
    return Gate(gate_name, params=params)**power


def get_rqc(n_qubits: int,
            n_gates: int,
            indexes: list[int] = None,
            randomize_power: bool = True,
            use_clifford_only: bool = False,
            use_random_indexes: bool = False):
    """
  Generate random quantum circuit.
  """

    # Initialize circuit
    circuit = Circuit()

    # If not provided, generate indexes
    if indexes is None:
        # Initialize
        indexes = []

        # Randomize indexes
        if use_random_indexes:

            # Add strings
            indexes = []
            while len(indexes) < n_qubits // 3:
                indexes += [
                    ''.join(
                        np.random.choice(list('abcdefghijklmnopqrstuvwxyz'),
                                         size=20))
                    for _ in range(n_qubits // 3 - len(indexes))
                ]

            # Add tuples
            while len(indexes) < n_qubits:
                indexes += [
                    tuple(x)
                    for x in np.unique(np.random.randint(-2**32 + 1,
                                                         2**32 - 1,
                                                         size=(n_qubits -
                                                               len(indexes),
                                                               2)),
                                       axis=0)
                ]

            # Random permutation
            indexes = [indexes[i] for i in np.random.permutation(n_qubits)]

        # Use sequential
        else:
            indexes = np.arange(n_qubits)

    # Check that size is correct
    assert (len(indexes) == n_qubits)

    # Add random gates
    for _ in range(n_gates):
        gate = get_random_gate(randomize_power=randomize_power,
                               use_clifford_only=use_clifford_only)
        gate.on([
            indexes[i]
            for i in np.random.choice(n_qubits,
                                      _available_gates[gate.name]['n_qubits'],
                                      replace=False)
        ],
                inplace=True)
        circuit.append(gate)

    # Return rqc
    return circuit

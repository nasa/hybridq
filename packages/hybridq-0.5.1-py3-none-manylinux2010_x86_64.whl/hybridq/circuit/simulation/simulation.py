"""
Author: Salvatore Mandra (salvatore.mandra@nasa.gov)

Copyright © 2021, United States Government, as represented by the Administrator
of the National Aeronautics and Space Administration. All rights reserved.

The HybridQ: A Hybrid Simulator for Quantum Circuits platform is licensed under
the Apache License, Version 2.0 (the "License"); you may not use this file
except in compliance with the License. You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.

Types
-----
**`Array`**: `numpy.ndarray`

**`TensorNetwork`**: `quimb.tensor.TensorNetwork`

**`ContractionInfo`**: `(opt_einsum.contract.PathInfo, cotengra.hyper.HyperOptimizer)`
"""

from __future__ import annotations
from warnings import warn
warn("""The C++ simulator for this package has been compiled for a
general x86-64 architecture. For a better performance, try
`pip install -U git+https://github.com/nasa/hybridq`.""")
from os import environ
from os.path import basename
_mpi_env = '_' in environ and basename(environ['_']) in ['mpiexec', 'mpirun']
_detect_mpi = 'DISABLE_MPI_AUTODETECT' not in environ and _mpi_env

import ctypes
from warnings import warn
from hybridq.gate import Gate
from hybridq.circuit import Circuit
from tqdm.auto import tqdm
from typing import TypeVar
from opt_einsum.contract import PathInfo
from opt_einsum import contract, get_symbol
from more_itertools import flatten
from sys import stderr
from time import time
import cotengra as ctg
import quimb.tensor as tn
import numpy as np
from hybridq.utils import sort, argsort, aligned_array
import hybridq.circuit.utils as utils
import numba

# Define types
Array = TypeVar('Array')
TensorNetwork = TypeVar('TensorNetwork')
ContractionInfo = TypeVar('ContractionInfo')


# Define shorthand for defining functions
def _define_function(lib, fname, restype, *argtypes):
    func = lib.__getattr__(fname)
    func.argtypes = argtypes
    func.restype = restype
    return func


@numba.vectorize
def _parity(v):
    v ^= v >> 16
    v ^= v >> 8
    v ^= v >> 4
    v &= 0xf
    if (0x6996 >> v) & 1:
        return -1
    else:
        return 1


def prepare_state(state: {str, list[complex]},
                  backend: any = 'numpy',
                  optimize: any = 'auto',
                  complex_type: any = 'complex64'):
    """
    Prepare initial state accordingly to `state`.

    Parameters
    ----------
    state: {str, list[complex]}
        State used to prepare the quantum state. If `state` is a string, a
        quantum state of `len(str)` is created using the following notation:

        - `0`: qubit is set to `0` in the computational basis,
        - `1`: qubit is set to `1` in the computational basis,
        - `+`: qubit is set to `+` state in the computational basis,
        - `-`: qubit is set to `-` state in the computational basis.

        If `state` is a `list` of `complex` number, it is checked that the
        number of element in state is a power of `2` and it returns an
        `Array` of type `complex_type`.
    backend: any
        Backend used to compute the quantum state. Backend must have
        `tensordot`, `transpose` and `einsum` methods.
    optimize: any
        Optimization to use in conjuction with `backend`.
    complex_type: any, optional
        Complex type to use to prepare the quantum state.

    Returns
    -------
    Array
        Quantum state prepared from `state`.

    Example
    -------
    >>> prepare_state('+-+')
    array([ 0.35355338+0.j,  0.35355338+0.j, -0.35355338+0.j, -0.35355338+0.j,
            0.35355338+0.j,  0.35355338+0.j, -0.35355338+0.j, -0.35355338+0.j],
          dtype=complex64)
    """

    if type(state) == str:

        # Get number of qubits
        n_qubits = len(state)

        # Simple cases
        if not set(state).difference(['0', '1']):
            # Initialize in the computational basis
            q_state = np.zeros(2**n_qubits, dtype=complex_type)
            q_state[int(state, 2)] = 1
            return q_state
        elif set(state) == {'+'}:
            # Initialize to superposition
            return np.ones(2**n_qubits, dtype=complex_type) / np.sqrt(2**
                                                                      n_qubits)

        # Check that only allowed symbols are contained
        if set(state).difference('+-01'):
            raise ValueError(
                f"Symbols {set(state).difference('+-01')} are not allowed.")

        # Get order
        order = [p for p, x in enumerate(state) if x in ['0', '1']]
        order += [p for p, x in enumerate(state) if x == '+']
        order += [p for p, x in enumerate(state) if x == '-']

        # Invert order
        order = [x for x, _ in sort(enumerate(order), key=lambda x: x[1])]

        # Check order
        assert (sort(order) == list(range(len(state))))

        # Count number of 0/1
        n_a = state.count('0') + state.count('1')

        # Count number of -
        n_b = state.count('+')

        # Count number of +
        n_c = state.count('-')

        # Check
        assert (n_a + n_b + n_c == len(state))

        # Initialize state
        q_state = np.zeros(shape=(2**n_a, 2**(n_b + n_c)), dtype=complex_type)

        # Get superposition
        q_state[int(''.join(
            x for x in state
            if x in ['0', '1']), 2) if n_a > 0 else 0] = np.concatenate(
                [_parity(np.arange(2**n_c))] * 2**n_b) / np.sqrt(2**(n_b + n_c))

        # Reshape state
        q_state = np.reshape(
            np.transpose(np.reshape(q_state, [2] * len(state)), order),
            [2**len(state)])

        # Return state
        return q_state

    else:
        try:
            state = np.array(state, dtype=complex_type)
            _n = np.log2(len(state))
            if len(state.shape) != 1 or int(_n) == 0 or _n != int(_n):
                raise ValueError("'state' is not a valid array.")
            else:
                return state
        except:
            raise ValueError(f"'state' is not valid.")


def simulate(circuit: {Circuit, TensorNetwork},
             initial_state: any = None,
             final_state: any = None,
             optimize: any = 'evolution',
             backend: any = 'numpy',
             complex_type: any = 'complex64',
             tensor_only: bool = False,
             simplify: bool = True,
             remove_id_gates: bool = True,
             use_mpi: bool = None,
             verbose: bool = False,
             **kwargs) -> any:
    """
    Frontend to simulate `Circuit` using different optimization models and
    backends.

    Parameters
    ----------
    circuit: {Circuit, TensorNetwork}
        Circuit to simulate.
    initial_state: any, optional
        Initial state to use.
    final_state: any, optional
        Final state to use (only valid for `optimize='tn'`).
    optimize: any, optional
        Optimization to use. At the moment, HybridQ supports two optimizations:
        `optimize='evolution'` (equivalent to `optimize='evolution-hybridq'`)
        and `optimize='tn'` (equivalent to `optimize='cotengra'`).
        `optimize='evolution'` takes an `initial_state` (it can either be a
        string, which is processed using ```prepare_state``` or an `Array`)
        and evolve the quantum state accordingly to `Circuit`. Alternatives are:

        - `optimize='evolution-hybridq'`: use internal `C++` implementation for
          quantum state evolution that uses vectorization instructions (such as
          AVX instructions for Intel processors). This optimization method is
          best suitable for `CPU`s.
        - `optimize='evolution-einsum'`: use `einsum` to perform the evolution
          of the quantum state (via `opt_einsum`). It is possible to futher
          specify optimization for `opt_einsum` by using
          `optimize='evolution-einsum-opt'` where `opt` is one of the available
          optimization in `opt_einsum.contract` (default: `auto`). This
          optimization is best suitable for `GPU`s and `TPU`s (using
          `backend='jax'`).

        `optimize='tn'` (or, equivalently, `optimize='cotengra'`) performs the
        tensor contraction of `Circuit` given an `initial_state` and a
        `final_state` (both must be a `str`). Valid tokens for both
        `initial_state` and `final_state` are:

        - `0`: qubit is set to `0` in the computational basis,
        - `1`: qubit is set to `1` in the computational basis,
        - `+`: qubit is set to `+` state in the computational basis,
        - `-`: qubit is set to `-` state in the computational basis,
        - `X`: qubit is left uncontracted.

        Before the actual contraction, `cotengra` is called to identify an
        optimal contraction. Such contraction is then used to perform the tensor
        contraction.

        If `Circuit` is a `TensorNetwork`, `optimize` must be a
        valid contraction (see `tensor_only` parameter).
    backend: any, optional
        Backend used to perform the simulation. Backend must have `tensordot`,
        `transpose` and `einsum` methods.
    complex_type: any, optional
        Complex type to use for the simulation.
    tensor_only: bool, optional
        If `True` and `optimize=None`, `simulate` will return a
        `TensorNetwork` representing `Circuit`. Otherwise, if
        `optimize='cotengra'`, `simulate` will return the `tuple`
        ```(TensorNetwork```, ```ContractionInfo)```. ```TensorNetwork``` and
        and ```ContractionInfo``` can be respectively used as values for
        `circuit` and `optimize` to perform the actual contraction.
    simplify: bool, optional
        Circuit is simplified before the simulation using utils.simplify.
    remove_id_gates: bool, optional
        Identity gates are removed before to perform the simulation.
        If `False`, identity gates are kept during the simulation.
    use_mpi: bool, optional
        Use `MPI` if available. Unless `use_mpi=False`, `MPI` will be used if
        detected (for instance, if `mpiexec` is used to called HybridQ). If
        `use_mpi=True`, force the use of `MPI` (in case `MPI` is not
        automatically detected).
    verbose: bool, optional
        Verbose output.

    Returns
    -------
    Output of `simulate` depends on the chosen parameters.

    Other Parameters
    ----------------
    parallel: int (default: False)
        Parallelize simulation (where possible). If `True`, the number of
        available cpus is used. Otherwise, a `parallel` number of threads is
        used.
    compress: int (default: auto)
        Select level of compression for ```hybridq.utils.compress```, which is
        run on `Circuit` prior to perform the simulation. If `compress=0`,
        compression of `Circuit` is skipped.
    block_until_ready: bool (default: True)
        When `backend='jax'`, wait till the results are ready before returning.
    return_numpy_array: bool (default: True)
        When `optimize='hybridq'`, aligned vectors are create to use
        vectorialization. If `False`, a `tuple` of `hybridq.utils.aligned_array`
        are returned, each one corresponding to the real and imaginary part
        of the quantum state respectively.
    return_info: bool (default: False)
        Return extra information collected during the simulation.
    simplify_tn: str (default: 'RC')
        Simplification to apply to `TensorNetwork`. Available simplifications as
        specified in `quimb.tensor.TensorNetwork.full_simplify`.
    max_largest_intermediate: int (default: 2**26)
        Largest intermediate which is allowed during simulation. If
        `optimize='evolution'`, `simulate` will raise an error if the
        largest intermediate is larger than `max_largest_intermediate`.  If
        `optimize='tn'`, slicing will be applied to fit the contraction in
        memory.
    target_largest_intermediate: int (default: 0)
        Stop `cotengra` if a contraction having the largest intermediate smaller
        than `target_largest_intermediate` is found.
    max_iterations: int (default: 1)
        Number of `cotengra` iterations to find optimal contration.
    max_time: int (default: 120)
        Maximum number of seconds allowed to `cotengra` to find optimal
        contraction for each iteration.
    max_repeats: int (default: 16)
        Number of `cotengra` steps to find optimal contraction for each
        iteration.
    temperatures: list[float] (default: [1.0, 0.1, 0.01])
        Temperatures used by `cotengra` to find optimal slicing of the tensor
        network.
    max_n_slices: int (default: None)
        If specified, `simulate` will raise an error if the number of
        slices to fit the tensor contraction in memory is larger than
        `max_n_slices`.
    minimize: str (default: 'combo')
        Cost function to minimize while looking for the best contraction (see
        `cotengra` for more information).
    methods: list[str] (default: ['kahypar', 'greedy'])
        Heuristics used by `cotengra` to find optimal contraction.
    optlib: str (default: 'baytune')
        Library used by `cotengra` to tune hyper-parameters while looking for
        the best contraction.
    sampler: str (default: 'GP')
        Sampler used by `cotengra` while looking for the contraction.
    cotengra: dict[any, any] (default: {})
        Extra parameters to pass to `cotengra`.
    """

    # Checks
    if tensor_only and type(optimize) == str and 'evolution' in optimize:
        raise ValueError(
            f"'tensor_only' is not support for optimize={optimize}")

    # Simplify circuit
    if isinstance(circuit, Circuit):
        # Get qubits
        qubits = circuit.all_qubits()
        n_qubits = len(qubits)

        # Check size of states
        _get_n_qubits = lambda state: len(state) if type(
            state) == str else np.log2(len(state))

        # If initial/final states are single chars, extend to the number of qubits
        if type(initial_state) == str and _get_n_qubits(initial_state) == 1:
            initial_state = initial_state * n_qubits
        if type(final_state) == str and _get_n_qubits(final_state) == 1:
            final_state = final_state * n_qubits

        # Few more checks
        if initial_state is not None and _get_n_qubits(
                initial_state) != n_qubits:
            raise ValueError(
                f"'initial_state' has a wrong number of qubits "
                f"(expected {n_qubits}, got {_get_n_qubits(initial_state)})")
        if final_state is not None and _get_n_qubits(final_state) != n_qubits:
            raise ValueError(
                f"'final_state' has a wrong number of qubits "
                f"(expected {n_qubits}, got {_get_n_qubits(final_state)})")

        # Strip Gate('I')
        if remove_id_gates:
            circuit = Circuit(gate for gate in circuit if gate.name != 'I')
        # Simplify circuit
        if simplify:
            circuit = utils.simplify(circuit,
                                     remove_id_gates=remove_id_gates,
                                     verbose=verbose)

        # Stop if qubits have changed
        if circuit.all_qubits() != qubits:
            raise ValueError(
                "Active qubits have changed after simplification. Forcing stop."
            )

    # Simulate
    if type(optimize) == str and 'evolution' in optimize:

        # Set default parameters
        optimize = '-'.join(optimize.split('-')[1:])
        if not optimize:
            optimize = 'hybridq'
        kwargs.setdefault('compress', 4 if optimize == 'hybridq' else 6)
        kwargs.setdefault('max_largest_intermediate', 2**26)
        kwargs.setdefault('return_info', False)
        kwargs.setdefault('block_until_ready', True)
        kwargs.setdefault('return_numpy_array', True)

        return _simulate_evolution(circuit, initial_state, final_state,
                                   optimize, backend, complex_type, verbose,
                                   **kwargs)
    else:

        # Set default parameters
        kwargs.setdefault('compress', 2)
        kwargs.setdefault('simplify_tn', 'RC')
        kwargs.setdefault('max_iterations', 1)
        try:
            import kahypar as __kahypar__
            kwargs.setdefault('methods', ['kahypar', 'greedy'])
        except ModuleNotFoundError:
            warn("Cannot find module kahypar. Remove it from defaults.")
            kwargs.setdefault('methods', ['greedy'])
        except ImportError:
            warn("Cannot import module kahypar. Remove it from defaults.")
            kwargs.setdefault('methods', ['greedy'])
        kwargs.setdefault('max_time', 120)
        kwargs.setdefault('max_repeats', 16)
        kwargs.setdefault('minimize', 'combo')
        kwargs.setdefault('optlib', 'baytune')
        kwargs.setdefault('sampler', 'GP')
        kwargs.setdefault('target_largest_intermediate', 0)
        kwargs.setdefault('max_largest_intermediate', 2**26)
        kwargs.setdefault('temperatures', [1.0, 0.1, 0.01])
        kwargs.setdefault('parallel', None)
        kwargs.setdefault('cotengra', {})
        kwargs.setdefault('max_n_slices', None)
        kwargs.setdefault('return_info', False)

        # If use_mpi==False, force the non-use of MPI
        if not (use_mpi == False) and (use_mpi or _detect_mpi):

            # Warn that MPI is used because detected
            if not use_mpi:
                warn("MPI has been detected. Using MPI.")

            from hybridq.circuit.simulation.simulation_mpi import _simulate_tn_mpi
            return _simulate_tn_mpi(circuit, initial_state, final_state,
                                    optimize, backend, complex_type,
                                    tensor_only, verbose, **kwargs)
        else:

            if _detect_mpi and use_mpi == False:
                warn(
                    "MPI has been detected but use_mpi==False. Not using MPI as requested."
                )

            return _simulate_tn(circuit, initial_state, final_state, optimize,
                                backend, complex_type, tensor_only, verbose,
                                **kwargs)


def _simulate_evolution(circuit: iter[Gate], initial_state: any,
                        final_state: any, optimize: any, backend: any,
                        complex_type: any, verbose: bool, **kwargs):
    """
    Perform simulation of the circuit by using the direct evolution of the quantum state.
    """

    if _detect_mpi:
        warn("Detected MPI but optimize='evolution' does not support MPI.")

    # Initialize info
    _sim_info = {}

    # Convert iterable to circuit
    circuit = Circuit(circuit)

    # Get number of qubits
    qubits = circuit.all_qubits()
    n_qubits = len(qubits)

    # Try to load libraries for hybridq
    if optimize == 'hybridq':
        try:
            # Load library
            _lib = ctypes.cdll.LoadLibrary('hybridq.so')
            _lib_swap = ctypes.cdll.LoadLibrary('hybridq_swap.so')

        except OSError:

            try:
                # Load required modules
                import sys
                from os import path

                # Try default location
                _loc = path.join(sys.base_prefix, 'lib')
                warn("Cannot find C++ HybridQ core. "
                     f"Try to locate in '{_loc}'.")

                # Load library
                _lib = ctypes.cdll.LoadLibrary(path.join(_loc, 'hybridq.so'))
                _lib_swap = ctypes.cdll.LoadLibrary(
                    path.join(_loc, 'hybridq_swap.so'))

            except OSError:

                warn("Cannot find C++ HybridQ core. "
                     "Falling back to optimize='evolution-einsum' instead.")
                optimize = 'einsum'
                _lib = _lib_swap = None

        # Load functions
        if all(x is not None for x in [_lib, _lib_swap]):

            # Get max swap
            _max_swap_size = _define_function(_lib_swap, "get_max_swap_size",
                                              ctypes.c_uint32)()

            # Get largest gate
            _largest_available_gate = _define_function(
                _lib, "largest_available_gate", ctypes.c_uint32)()

            # Get pack size
            _log2_pack_size = _define_function(_lib, "get_log2_pack_size",
                                               ctypes.c_uint32)()

    # If the system is too small, fallback to einsum
    if optimize == 'hybridq' and n_qubits < max(_log2_pack_size,
                                                _max_swap_size):
        warn("The system is too small to use optimize='evolution-hybridq'. "
             "Falling back to optimize='evolution-einsum'")
        optimize = 'einsum'

    if verbose:
        print(f'# Optimization: {optimize}', file=stderr)

    # Check memory
    if 2**n_qubits > kwargs['max_largest_intermediate']:
        raise MemoryError(
            "Memory for the given number of qubits exceeds the 'max_largest_intermediate'."
        )

    # If final_state is specified, warn user
    if final_state is not None:
        warn(
            f"'final_state' cannot be specified in optimize='{optimize}'. Ignoring 'final_state'."
        )

    # Add initial state
    if initial_state is None:
        raise ValueError(
            "'initial_state' must be specified for optimize='evolution'.")

    elif type(initial_state) == str:

        # Check number of qubits
        if len(initial_state) != n_qubits:
            raise ValueError(
                f"'initial_state' has a wrong number of qubits (expected {n_qubits}, got {len(initial_state)})"
            )

        # Check state
        if set(initial_state).difference(['0', '1', '+', '-']):
            raise ValueError(
                f"initial_state={initial_state} not supported. Only {{0, 1, +, -}} are allowed."
            )

        if not set(initial_state).difference(['0', '1']):
            # Initialize in the computational basis
            initial_state = int(initial_state, 2)
        elif set(initial_state) == {'+'}:
            # Superposition
            initial_state = '+'
        else:
            # Initialize map
            _map = {x: q for x, q in enumerate(circuit.all_qubits())}

            # Initialize circuit
            _circuit = Circuit([])

            for x, g in enumerate(initial_state):
                if g == '+':
                    _circuit.append(Gate('H', [_map[x]]))
                elif g == '-':
                    _circuit.extend(
                        [Gate('X', [_map[x]]),
                         Gate('H', [_map[x]])])
                elif g == '1':
                    _circuit.append(Gate('X', [_map[x]]))

            # Update circuit
            circuit = _circuit + circuit

            # Unset initial_state
            initial_state = None

    else:

        # Check that the number of qubits match
        if int(np.log2(len(initial_state))) != n_qubits:
            raise ValueError(
                f"'initial_state' has a wrong number of qubits (expected {n_qubits}, got {len(initial_state)})"
            )

    # Convert complex_type to np.dtype
    complex_type = np.dtype(complex_type)

    # Get unitary matrices from gates
    if verbose:
        print(f"Compress circuit (max_qubits={kwargs['compress']}): ",
              end='',
              file=stderr)
        _time = time()
    circuit = utils.compress(circuit, kwargs['compress'], verbose=verbose)
    circuit = Circuit(
        utils.to_matrix_gate(c, complex_type=complex_type) for c in circuit)
    if verbose:
        print(f"Done! ({time()-_time:1.2f}s)", file=stderr)

    # Check largest number of qubits involved in gate
    if optimize == 'hybridq' and max(
            len(gate.qubits) for gate in circuit) > min(
                _largest_available_gate, _max_swap_size - _log2_pack_size):
        warn(f"optimize='evolution-hybridq' is optimized to use up to "
             f"{min(_largest_available_gate, _max_swap_size - _log2_pack_size)}"
             f"-qubit gates. Using optimize='evolution-einsum' instead.")
        optimize = 'einsum'

    if optimize == 'hybridq':

        if complex_type not in ['complex64', 'complex128']:
            warn(
                "optimize=evolution-hybridq only support ['complex64', 'complex128']. Using 'complex64'."
            )
            complex_type = np.dtype('complex64')

        # Get float_type
        float_type = np.real(np.array(1, dtype=complex_type)).dtype

        # Get C float_type
        c_float_type = {
            np.dtype('float32'): ctypes.c_float,
            np.dtype('float64'): ctypes.c_double
        }[float_type]

        # Load libraries
        _apply_U = _define_function(_lib, f"apply_U_{float_type}", ctypes.c_int,
                                    ctypes.POINTER(c_float_type),
                                    ctypes.POINTER(c_float_type),
                                    ctypes.POINTER(c_float_type),
                                    ctypes.POINTER(ctypes.c_uint32),
                                    ctypes.c_uint, ctypes.c_uint)

        _swap = _define_function(_lib_swap, f"swap_{float_type}", ctypes.c_int,
                                 ctypes.POINTER(c_float_type),
                                 ctypes.POINTER(ctypes.c_uint32), ctypes.c_uint)

        _to_complex = _define_function(_lib, f"to_{complex_type}", ctypes.c_int,
                                       ctypes.POINTER(c_float_type),
                                       ctypes.POINTER(c_float_type),
                                       ctypes.POINTER(c_float_type),
                                       ctypes.c_uint)

        # Get aligned state
        _psi_re = aligned_array(2**n_qubits, alignment=32, dtype=float_type)
        _psi_im = aligned_array(2**n_qubits, alignment=32, dtype=float_type)

        if initial_state is None:
            # Initialize state to 0...0
            _psi_re.buffer().fill(0)
            _psi_im.buffer().fill(0)
            _psi_re[0] = 1
        elif type(initial_state) is int:
            # Initialize to a bitstring in the computational basis
            _psi_re.buffer().fill(0)
            _psi_im.buffer().fill(0)
            _psi_re[initial_state] = 1
        elif type(initial_state) is str and initial_state == '+':
            # Superposition
            _psi_re.buffer().fill(1 / np.sqrt(2**n_qubits))
            _psi_im.buffer().fill(0)
        else:
            # Copy to allocated memory
            np.copyto(_psi_re.buffer(), np.real(initial_state))
            np.copyto(_psi_im.buffer(), np.imag(initial_state))

        # Create index maps
        _map = {q: n_qubits - x - 1 for x, q in enumerate(qubits)}
        _inv_map = [q for q, _ in sort(_map.items(), key=lambda x: x[1])]

        # Start clock
        _ini_time = time()

        # Apply all gates
        for gate in tqdm(circuit, disable=not verbose):

            # Check if any qubits is withing the pack_size
            if any(q in _inv_map[:_log2_pack_size] for q in gate.qubits):

                # Get new order
                _order = [
                    x for x, q in enumerate(_inv_map[:_max_swap_size])
                    if q not in gate.qubits
                ]
                _order += [
                    x for x, q in enumerate(_inv_map[:_max_swap_size])
                    if q in gate.qubits
                ]

                # Update maps
                _inv_map[:_max_swap_size] = [
                    _inv_map[:_max_swap_size][x] for x in _order
                ]
                _map.update(
                    {q: x for x, q in enumerate(_inv_map[:_max_swap_size])})

                # Apply swap
                _order = np.array(_order, dtype='uint32')
                _swap(_psi_re.c_ptr,
                      _order.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)),
                      n_qubits)
                _swap(_psi_im.c_ptr,
                      _order.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)),
                      n_qubits)

            # Get positions
            _pos = np.array([_map[q] for q in reversed(gate.qubits)],
                            dtype='uint32')

            # Get unitaries
            _U = gate.unitary()

            # Apply unitary
            if _apply_U(_psi_re.c_ptr, _psi_im.c_ptr,
                        _U.ctypes.data_as(ctypes.POINTER(c_float_type)),
                        _pos.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)),
                        n_qubits, len(_pos)):

                raise ValueError('something went wrong')

        # Check maps are still consistent
        assert (all(_inv_map[_map[q]] == q for q in _map))

        # Swap back to the correct order
        _order = np.array([
            _inv_map.index(q) for q in reversed(circuit.all_qubits())
        ][:_max_swap_size],
                          dtype='uint32')
        _swap(_psi_re.c_ptr,
              _order.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)), n_qubits)
        _swap(_psi_im.c_ptr,
              _order.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)), n_qubits)

        # Stop clock
        _end_time = time()

        # Copy the results
        if kwargs['return_numpy_array']:
            _psi = np.empty(2**n_qubits, dtype=complex_type)
            _to_complex(_psi_re.c_ptr, _psi_im.c_ptr,
                        _psi.ctypes.data_as(ctypes.POINTER(c_float_type)),
                        n_qubits)
        else:
            _psi = (_psi_re, _psi_im)

        # Update info
        _sim_info['runtime (s)'] = _end_time - _ini_time

    elif optimize.split('-')[0] == 'einsum':

        optimize = '-'.join(optimize.split('-')[1:])
        if not optimize:
            optimize = 'auto'

        # Order circuit in moments
        circuit = Circuit(flatten(utils.moments(circuit)))

        if initial_state is None:
            # Initialize to 0...0
            initial_state = np.zeros(2**n_qubits, dtype=complex_type)
            initial_state[0] = 1
        elif type(initial_state) is int:
            # Initialize to a bitstring in the computational basis
            _p = initial_state
            initial_state = np.zeros(2**n_qubits, dtype=complex_type)
            initial_state[_p] = 1
        elif type(initial_state) is str and initial_state == '+':
            # Superposition
            initial_state = np.ones(2**n_qubits, dtype=complex_type) / np.sqrt(
                2**n_qubits)

        # Reshape
        initial_state = np.reshape(initial_state, [2] * n_qubits)

        # Get gates and corresponding qubits
        _qubits, _gates = zip(
            *((c.qubits,
               np.reshape(c.unitary().astype(complex_type), (2,) *
                          (2 * len(c.qubits)))) for c in circuit))

        # Initialize map
        _map = {q: get_symbol(x) for x, q in enumerate(qubits)}
        _count = n_qubits
        _path = ''.join((_map[q] for q in qubits))

        # Generate map
        for _qs in _qubits:

            # Initialize local paths
            _path_in = _path_out = ''

            # Add incoming legs
            for _q in _qs:
                _path_in += _map[_q]

            # Add outcoming legs
            for _q in _qs:
                _map[_q] = get_symbol(_count)
                _count += 1
                _path_out += _map[_q]

            # Update path
            _path = _path_out + _path_in + ',' + _path

        # Make sure that qubits order is preserved
        _path += '->' + ''.join([_map[q] for q in qubits])

        # Contracts
        _ini_time = time()
        _psi = np.reshape(
            contract(_path,
                     *reversed(_gates),
                     initial_state,
                     dtype=complex_type,
                     backend=backend,
                     optimize=optimize), (2**n_qubits,))

        # Block JAX until result is ready (for a more precise runtime)
        if backend == 'jax' and kwargs['block_until_ready']:
            _psi.block_until_ready()

        _end_time = time()

        # Update info
        _sim_info['runtime (s)'] = _end_time - _ini_time

    else:

        raise ValueError(f"optimize='{optimize}' not implemented.")

    if verbose:
        print(f'# Runtime (s): {_sim_info["runtime (s)"]:1.2f}', file=stderr)

    # Return state
    if kwargs['return_info']:
        return _psi, _sim_info
    else:
        return _psi


def _simulate_tn(circuit: any, initial_state: any, final_state: any,
                 optimize: any, backend: any, complex_type: any,
                 tensor_only: bool, verbose: bool, **kwargs):

    # Get random leaves_prefix
    leaves_prefix = ''.join(
        np.random.choice(list('abcdefghijklmnopqrstuvwxyz'), size=20))

    # Initialize info
    _sim_info = {}

    # Alias for tn
    if optimize == 'tn':
        optimize = 'cotengra'

    if isinstance(circuit, Circuit):

        # Get number of qubits
        qubits = circuit.all_qubits()
        n_qubits = len(qubits)

        if 2**((0 if initial_state is None else initial_state.count('X')) +
               (0 if final_state is None else final_state.count('X'))
              ) > kwargs['max_largest_intermediate']:
            raise MemoryError(
                "Memory for the given number of open qubits exceeds the 'max_largest_intermediate'."
            )

        # Compress circuit
        if kwargs['compress']:
            if verbose:
                print(f"Compress circuit (max_qubits={kwargs['compress']}): ",
                      end='',
                      file=stderr)
                _time = time()
            circuit = utils.compress(circuit,
                                     kwargs['compress'],
                                     verbose=verbose)
            circuit = Circuit(
                utils.to_matrix_gate(c, complex_type=complex_type)
                for c in circuit)
            if verbose:
                print(f"Done! ({time()-_time:1.2f}s)", file=stderr)

        # Get qubits
        qubits = circuit.all_qubits()
        n_qubits = len(qubits)

        # Get tensor network representation of circuit
        tensor, tn_qubits_map = utils.to_tn(circuit,
                                            return_qubits_map=True,
                                            leaves_prefix=leaves_prefix)

        def _attach_state(tensor: TensorNetwork, state: str, ext: str):
            if state is not None:

                # To upper
                state = state.upper()

                # Check state is a string
                if type(state) != str:
                    raise ValueError(f"Only strings are supported for states.")

                # Check if the number of qubits is correct
                if len(state) != n_qubits:
                    raise ValueError(
                        f"'state' has a wrong number of qubits (expected {n_qubits}, got {len(initial_state)})"
                    )

                # Attach state to tensor
                for s, q in zip(state, qubits):

                    tags = [
                        f'{leaves_prefix}_{tn_qubits_map[q]}', f'gate-idx_{ext}'
                    ]
                    if s == '0':
                        tensor &= tn.Tensor(
                            [1, 0],
                            inds=[f'{leaves_prefix}_{tn_qubits_map[q]}_{ext}'],
                            tags=tags)
                    elif s == '1':
                        tensor &= tn.Tensor(
                            [0, 1],
                            inds=[f'{leaves_prefix}_{tn_qubits_map[q]}_{ext}'],
                            tags=tags)
                    elif s == '+':
                        tensor &= tn.Tensor(
                            np.array([1, 1]) / np.sqrt(2),
                            inds=[f'{leaves_prefix}_{tn_qubits_map[q]}_{ext}'],
                            tags=tags)
                    elif s == '-':
                        tensor &= tn.Tensor(
                            np.array([1, -1]) / np.sqrt(2),
                            inds=[f'{leaves_prefix}_{tn_qubits_map[q]}_{ext}'],
                            tags=tags)
                    elif s == 'X':
                        pass
                    else:
                        raise ValueError(
                            f"Symbol '{s}' not supported in state.")

        # Attach initial_state
        if initial_state is not None:
            _attach_state(tensor, initial_state, 'i')

        # Attach final_state
        if final_state is not None:
            _attach_state(tensor, final_state, 'f')

        # Simplify if requested
        if kwargs['simplify_tn']:
            tensor.full_simplify_(kwargs['simplify_tn']).astype_(complex_type)
        else:
            # Otherwise, just convert to the given complex_type
            tensor.astype_(complex_type)

        # Get contraction from heuristic
        if optimize == 'cotengra' and kwargs['max_iterations'] > 0:

            # Create local client if MPI has been detected (not compatible with Dask at the moment)
            if _mpi_env and kwargs['parallel']:

                from distributed import Client, LocalCluster
                _client = Client(LocalCluster(processes=False))

            else:

                _client = None

            # Set cotengra parameters
            cotengra_params = lambda: ctg.HyperOptimizer(
                methods=kwargs['methods'],
                max_time=kwargs['max_time'],
                max_repeats=kwargs['max_repeats'],
                minimize=kwargs['minimize'],
                optlib=kwargs['optlib'],
                sampler=kwargs['sampler'],
                progbar=verbose,
                parallel=kwargs['parallel'],
                **kwargs['cotengra'])

            # Get optimized path
            opt = cotengra_params()
            info = tensor.contract(all, optimize=opt, get='path-info')

            # Get target size
            tli = kwargs['target_largest_intermediate']

            # Repeat for the requested number of iterations
            for _ in range(1, kwargs['max_iterations']):

                # Break if largest intermediate is equal or smaller than target
                if info.largest_intermediate <= tli:
                    break

                # Otherwise, restart
                _opt = cotengra_params()
                _info = tensor.contract(all, optimize=_opt, get='path-info')

                # Store the best
                if kwargs['minimize'] == 'size':

                    if _info.largest_intermediate < info.largest_intermediate or (
                            _info.largest_intermediate
                            == info.largest_intermediate and
                            _opt.best['flops'] < opt.best['flops']):
                        info = _info
                        opt = _opt

                else:

                    if _opt.best['flops'] < opt.best['flops'] or (
                            _opt.best['flops'] == opt.best['flops'] and
                            _info.largest_intermediate <
                            info.largest_intermediate):
                        info = _info
                        opt = _opt

            # Close client if exists
            if _client:

                _client.shutdown()
                _client.close()

        # Just return tensor if required
        if tensor_only:
            if optimize == 'cotengra' and kwargs['max_iterations'] > 0:
                return tensor, (info, opt)
            else:
                return tensor

    else:

        # Set tensor
        tensor = circuit

        if len(optimize) == 2 and isinstance(
                optimize[0], PathInfo) and isinstance(optimize[1],
                                                      ctg.hyper.HyperOptimizer):

            # Get info and opt from optimize
            info, opt = optimize

            # Set optimization
            optimize = 'cotengra'

        else:

            # Get tensor and path
            tensor = circuit

    # Print some info
    if verbose:
        print(
            f'Largest Intermediate: 2^{np.log2(float(info.largest_intermediate)):1.2f}',
            file=stderr)
        print(
            f'Max Largest Intermediate: 2^{np.log2(float(kwargs["max_largest_intermediate"])):1.2f}',
            file=stderr)
        print(f'Flops: 2^{np.log2(float(info.opt_cost)):1.2f}', file=stderr)

    if optimize == 'cotengra':

        # Get indexes
        _inds = tensor.outer_inds()

        # Get input indexes and output indexes
        _i_inds = sort([x for x in _inds if x[-2:] == '_i'],
                       key=lambda x: int(x.split('_')[1]))
        _f_inds = sort([x for x in _inds if x[-2:] == '_f'],
                       key=lambda x: int(x.split('_')[1]))

        # Get order
        _inds = [_inds.index(x) for x in _i_inds + _f_inds]

        # Get slice finder
        sf = ctg.SliceFinder(info,
                             target_size=kwargs['max_largest_intermediate'])

        # Find slices
        with tqdm(kwargs['temperatures'], disable=not verbose,
                  leave=False) as pbar:
            for _temp in pbar:
                pbar.set_description(f'Find slices (T={_temp})')
                ix_sl, cost_sl = sf.search(temperature=_temp)

        # Get slice contractor
        sc = sf.SlicedContractor([t.data for t in tensor])

        # Update infos
        _sim_info.update({
            'flops': info.opt_cost,
            'largest_intermediate': info.largest_intermediate,
            'n_slices': cost_sl.nslices,
            'total_flops': cost_sl.total_flops
        })

        # Print some infos
        if verbose:
            print(f'Number of slices: 2^{np.log2(float(cost_sl.nslices)):1.2f}',
                  file=stderr)
            print(f'Flops+Cuts: 2^{np.log2(float(cost_sl.total_flops)):1.2f}',
                  file=stderr)

        if kwargs['max_n_slices'] and sc.nslices > kwargs['max_n_slices']:
            raise ValueError(
                f'Too many slices ({sc.nslices} > {kwargs["max_n_slices"]})')

        # Contract tensor
        _li = np.log2(float(info.largest_intermediate))
        _mli = np.log2(float(kwargs["max_largest_intermediate"]))
        _tensor = sc.gather_slices(
            (sc.contract_slice(i, backend=backend) for i in tqdm(
                range(sc.nslices),
                desc=f'Contracting tensor (li=2^{_li:1.0f}, mli=2^{_mli:1.1f})',
                leave=False)))

        # Create map
        _map = ''.join([get_symbol(x) for x in range(len(_inds))])
        _map += '->'
        _map += ''.join([get_symbol(x) for x in _inds])

        # Reorder tensor
        tensor = contract(_map, _tensor)

        if _inds:

            # Reshape tensor
            if _i_inds and _f_inds:
                tensor = np.reshape(tensor, (2**len(_i_inds), 2**len(_f_inds)))
            else:
                tensor = np.reshape(tensor,
                                    (2**max(len(_i_inds), len(_f_inds)),))

    else:

        # Contract tensor
        tensor = tensor.contract(optimize=optimize, backend=backend)

        if hasattr(tensor, 'inds'):

            # Get input indexes and output indexes
            _i_inds = sort([x for x in tensor.inds if x[-2:] == '_i'],
                           key=lambda x: int(x.split('_')[1]))
            _f_inds = sort([x for x in tensor.inds if x[-2:] == '_f'],
                           key=lambda x: int(x.split('_')[1]))

            # Transpose tensor
            tensor.transpose(*(_i_inds + _f_inds), inplace=True)

            # Reshape tensor
            if _i_inds and _f_inds:
                tensor = np.reshape(tensor, (2**len(_i_inds), 2**len(_f_inds)))
            else:
                tensor = np.reshape(tensor,
                                    (2**max(len(_i_inds), len(_f_inds)),))

    if kwargs['return_info']:
        return tensor, _sim_info
    else:
        return tensor


def expectation_value(state: Array,
                      op: Circuit,
                      qubits_order: iter[any],
                      complex_type: any = 'complex64',
                      backend: any = 'numpy',
                      verbose: bool = False,
                      **kwargs) -> complex:
    """
    Compute expectation value of an operator given a quantum state.

    Parameters
    ----------
    state: Array
        Quantum state to use to compute the expectation value of the operator
        `op`.
    op: Circuit
        Quantum operator to use to compute the expectation value.
    qubits_order: iter[any]
        Order of qubits used to map `Circuit.qubits` to `state`.
    complex_type: any, optional
        Complex type to use to compute the expectation value.
    backend: any, optional
        Backend used to compute the quantum state. Backend must have
        `tensordot`, `transpose` and `einsum` methods.
    verbose: bool, optional
        Verbose output.

    Returns
    -------
    complex
        The expectation value of the operator `op` given `state`.

    Other Parameters
    ----------------
    `expectation_value` accepts all valid parameters for `simulate`.

    See Also
    --------
    `simulate`

    Example
    -------
    >>> op = Circuit([
    >>>     Gate('H', qubits=[32]),
    >>>     Gate('CX', qubits=[32, 42]),
    >>>     Gate('RX', qubits=[12], params=[1.32])
    >>> ])
    >>> expectation_value(
    >>>     state=prepare_state('+0-'),
    >>>     op=op,
    >>>     qubits_order=[12, 42, 32],
    >>> )
    array(0.55860883-0.43353909j)
    """

    # Fix remove_id_gates
    kwargs['remove_id_gates'] = False

    # Get number of qubits
    n_qubits = int(np.log2(len(state)))

    # Check number of qubits is consistent with state
    if state.shape != (2**n_qubits,):
        raise ValueError("'state' is not valid.")

    # Convert qubits_order to a list
    qubits_order = list(qubits_order)

    # Check lenght of qubits_order
    if len(qubits_order) != n_qubits:
        raise ValueError(
            "'qubits_order' must have the same number of qubits of 'state'.")

    # Check that qubits in op are a subset of qubits_order
    if set(op.all_qubits()).difference(qubits_order):
        raise ValueError("'op' has qubits not included in 'qubits_order'.")

    # Add Gate('I') to op for not used qubits
    op = op + [
        Gate('I', qubits=[q])
        for q in set(qubits_order).difference(op.all_qubits())
    ]

    # Simulate op with given state
    _state = simulate(op,
                      initial_state=state,
                      optimize='evolution',
                      complex_type=complex_type,
                      backend=backend,
                      verbose=verbose,
                      **kwargs)

    # Return expectation value
    return np.real_if_close(_state.dot(state.conj()))

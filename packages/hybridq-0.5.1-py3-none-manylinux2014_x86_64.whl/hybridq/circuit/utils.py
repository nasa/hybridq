"""
Author: Salvatore Mandra (salvatore.mandra@nasa.gov)

Copyright © 2021, United States Government, as represented by the Administrator
of the National Aeronautics and Space Administration. All rights reserved.

The HybridQ: A Hybrid Simulator for Quantum Circuits platform is licensed under
the Apache License, Version 2.0 (the "License"); you may not use this file
except in compliance with the License. You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from __future__ import annotations
from functools import partial as partial_func
from collections import deque
from copy import deepcopy
from hybridq.gate import Gate
from hybridq.utils import sort, argsort
from opt_einsum import contract, get_symbol
from hybridq.circuit import Circuit
from tqdm.auto import tqdm
import quimb.tensor as tn
import networkx as nx
import numpy as np


def isclose(a: Circuit,
            b: Circuit,
            use_commutation: bool = True,
            atol: float = 1e-8,
            verbose: bool = False):
    """
    Check if `a` is close to `b` within the absolute tollerance
    `atol`.

    Parameters
    ----------
    circuit: Circuit[Gate]
        `Circuit` to compare with.
    use_commutation: bool
        Use commutation rules. See `hybridq.circuit.utils.simplify`.
    atol: float, optional
        Absolute tollerance.

    Returns
    -------
    bool
        `True` if the two circuits are close within the absolute tollerance
        `atol`, and `False` otherwise.

    See Also
    --------
    hybridq.circuit.utils.simplify

    Example
    -------
    >>> c = Circuit(Gate('H', [q]) for q in range(10))
    >>> c.isclose(Circuit(g**1.1 for g in c))
    False
    >>> c.isclose(Circuit(g**1.1 for g in c), atol=1e-1)
    True
    """

    # Get simplified circuit
    s = simplify(a + b.inv(),
                 use_commutation=use_commutation,
                 atol=atol,
                 verbose=verbose)

    return not s or all(
        np.allclose(g.unitary(), np.eye(2**len(g.qubits)), atol=atol)
        for g in tqdm(s, disable=not verbose, desc='Check'))


def insert_from_left(circuit: iter[Gate],
                     gate: Gate,
                     atol: float = 1e-8,
                     *,
                     use_commutation: bool = True,
                     simplify: bool = True,
                     pop: bool = False,
                     pinned_qubits: list[any] = None,
                     inplace: bool = False) -> Circuit:
    """
    Add a gate to circuit starting from the left, commuting with existing gates if necessary.
    """

    # Copy circuit if required
    if not inplace:
        circuit = Circuit(circuit, copy=True)

    # Get qubits
    _qubits = set(gate.qubits)

    # Iterate over all the gates
    for _p, _g in enumerate(circuit):
        # Remove if gate simplifies with _g
        if simplify and gate.inv().isclose(_g, atol=atol):
            del (circuit[_p])
            return circuit

        # Otherwise, check if gate can commute with _g. If not, insert gate
        # and exit loop.
        elif _qubits.intersection(
                _g.qubits) and not (use_commutation and
                                    gate.commutes_with(_g, atol=atol)):
            circuit.insert(_p, deepcopy(gate))
            return circuit

    # If commutes with everything, just append at the end
    if not pop or set(gate.qubits).intersection(pinned_qubits):
        circuit.append(deepcopy(gate))

    # Return circuit if change wasn't in place
    return circuit


def to_nx(circuit: iter[Gate],
          add_final_nodes: bool = True,
          node_tags: dict = None,
          edge_tags: dict = None,
          return_qubits_map: bool = False,
          leaves_prefix: str = 'q') -> networkx.Graph:
    """
    Return graph representation of circuit. `to_nx` is deterministic, so it can
    be reused elsewhere.

    Parameters
    ----------
    circuit: iter[Gate]
        Circuit to get graph representation from.
    add_final_nodes: bool, optional
        Add final nodes for each qubit to the graph representation of `circuit`.
    node_tags: dict, optional
        Add specific tags to nodes.
    edge_tags: dict, optional
        Add specific tags to edges.
    return_qubits_map: bool, optional
        Return map associated to the Circuit qubits.
    leaves_prefix: str, optional
        Specify prefix to use for leaves.

    Returns
    -------
    networkx.Graph
        Graph representing `circuit`.

    Example
    -------
    >>> import networkx as nx
    >>>
    >>> # Define circuit
    >>> circuit = Circuit(
    >>>     [Gate('X', qubits=[0])**1.2,
    >>>      Gate('ISWAP', qubits=[0, 1])**2.3], Gate('H', [1]))
    >>>
    >>> # Draw graph
    >>> nx.draw_planar(utils.to_nx(circuit))

    .. image:: ../../images/circuit_nx.png
    """

    # Initialize
    if node_tags is None:
        node_tags = {}
    if edge_tags is None:
        edge_tags = {}

    # Check if node is a leaf
    def _is_leaf(node):
        return type(node) == str and node[:len(leaves_prefix)] == leaves_prefix

    # Convert iterable to Circuit
    circuit = Circuit(circuit)

    # Get graph
    graph = nx.DiGraph()

    # Get qubits
    qubits = circuit.all_qubits()

    # Get qubits_map
    qubits_map = {q: i for i, q in enumerate(qubits)}

    # Check that no qubits is 'confused' as leaf
    if any(_is_leaf(q) for q in qubits):
        raise ValueError(
            f"No qubits must start with 'leaves_prefix'={leaves_prefix}.")

    # Add first layer
    for q in qubits:
        graph.add_node(f'{leaves_prefix}_{qubits_map[q]}_i',
                       qubits=[q],
                       **node_tags)

    # Last leg
    last_leg = {q: f'{leaves_prefix}_{qubits_map[q]}_i' for q in qubits}

    # Build network
    for x, gate in enumerate(circuit):

        # Add node
        graph.add_node(x,
                       circuit=Circuit([gate]),
                       qubits=sort(gate.qubits),
                       **node_tags)

        # Add edges (time directed)
        graph.add_edges_from([(last_leg[q], x) for q in gate.qubits],
                             **edge_tags)

        # Update last_leg
        last_leg.update({q: x for q in gate.qubits})

    # Add last indexes if required
    if add_final_nodes:
        for q in qubits:
            graph.add_node(f'{leaves_prefix}_{qubits_map[q]}_f',
                           qubits=[q],
                           **node_tags)
        graph.add_edges_from([(x, f'{leaves_prefix}_{qubits_map[q]}_f')
                              for q, x in last_leg.items()], **edge_tags)

    if return_qubits_map:
        return graph, qubits_map
    else:
        return graph


def to_tn(circuit: iter[Gate],
          complex_type: any = 'complex64',
          return_qubits_map: bool = False,
          leaves_prefix: str = 'q_') -> quimb.tensor.TensorNetwork:
    """
    Return `quimb.tensor.TensorNetwork` representing `circuit`. `to_tn` is
    deterministic, so it can be reused elsewhere.

    Parameters
    ----------
    circuit: iter[Gate]
        Circuit to get `quimb.tensor.TensorNetwork` representation from.
    complex_type: any, optional
        Complex type to use while getting the `quimb.tensor.TensorNetwork`
        representation.
    return_qubits_map: bool, optional
        Return map associated to the Circuit qubits.
    leaves_prefix: str, optional
        Specify prefix to use for leaves.

    Returns
    -------
    quimb.tensor.TensorNetwork
        Tensor representing `circuit`.

    Example
    -------
    >>> # Define circuit
    >>> circuit = Circuit(
    >>>     [Gate('X', qubits=[0])**1.2,
    >>>      Gate('ISWAP', qubits=[0, 1])**2.3], Gate('H', [1]))
    >>>
    >>> # Draw graph
    >>> utils.to_tn(circuit).graph()

    .. image:: ../../images/circuit_tn.png
    """

    # Convert iterable to Circuit
    circuit = Circuit(circuit)

    # Get all qubits
    all_qubits = circuit.all_qubits()

    # Get qubits map
    qubits_map = {q: i for i, q in enumerate(all_qubits)}

    # Get last_tag
    last_tag = {q: 'i' for q in all_qubits}

    # Node generator
    def _get_node(t, gate):

        # Get unitary
        U = np.reshape(gate.unitary().astype(complex_type),
                       [2] * (2 * len(gate.qubits)))

        # Get indexes
        inds = [f'{leaves_prefix}_{qubits_map[q]}_{t}' for q in gate.qubits] + [
            f'{leaves_prefix}_{qubits_map[q]}_{last_tag[q]}'
            for q in gate.qubits
        ]

        # Update last_tag
        for q in gate.qubits:
            last_tag[q] = t

        # Return node
        return tn.Tensor(
            U.astype(complex_type),
            inds=inds,
            tags=[f'{leaves_prefix}_{qubits_map[q]}' for q in gate.qubits] +
            [f'gate-idx_{t}'])

    # Get list of tensors
    tensor = [_get_node(t, gate) for t, gate in enumerate(circuit)]

    # Generate new output map
    output_map = {
        f'{leaves_prefix}_{qubits_map[q]}_{t}':
        f'{leaves_prefix}_{qubits_map[q]}_f' for q, t in last_tag.items()
    }

    # Rename output legs
    for node in tensor:
        node.reindex(output_map, inplace=True)

    # Return tensor network
    if return_qubits_map:
        return tn.TensorNetwork(tensor), qubits_map
    else:
        return tn.TensorNetwork(tensor)


def to_matrix_gate(circuit: iter[Gate],
                   complex_type: any = 'complex64',
                   **kwargs) -> Gate:
    """
    Convert `circuit` to a matrix `Gate`.

    Parameters
    ----------
    circuit: iter[Gate]
        Circuit to convert to `Gate('MATRIX')`.
    complex_type: any, optional
        Float type to use while converting to `Gate('MATRIX')`

    Returns
    -------
    Gate
        `Gate('MATRIX')` representing `circuit`.

    Example
    -------
    >>> # Define circuit
    >>> circuit = Circuit(
    >>>     [Gate('X', qubits=[0])**1.2,
    >>>      Gate('ISWAP', qubits=[0, 1])**2.3])
    >>>
    >>> gate = utils.to_matrix_gate(circuit)
    >>> gate
    Gate(name=MATRIX, qubits=[0, 1], U=np.array(shape=(4, 4), dtype=complex64))
    >>> gate.U
    array([[ 0.09549151-0.29389262j,  0.        +0.j        ,
             0.9045085 +0.29389262j,  0.        +0.j        ],
           [ 0.13342446-0.41063824j, -0.08508356+0.26186025j,
            -0.13342446-0.04335224j, -0.8059229 -0.26186025j],
           [-0.8059229 -0.26186025j, -0.13342446-0.04335224j,
            -0.08508356+0.26186025j,  0.13342446-0.41063824j],
           [ 0.        +0.j        ,  0.9045085 +0.29389262j,
             0.        +0.j        ,  0.09549151-0.29389262j]],
          dtype=complex64)
    """

    # Convert iterable to Circuit
    circuit = Circuit(circuit)

    return Gate('MATRIX',
                qubits=circuit.all_qubits(),
                U=unitary(circuit, complex_type=complex_type, **kwargs))


def compress(circuit: iter[{Gate, Circuit}],
             max_qubits: int = 2,
             *,
             exclude_qubits: iter[any] = None,
             use_commutation: bool = True,
             atol: float = 1e-8,
             verbose: bool = False) -> list[Circuit]:
    """
    Compress gates together up to the specified number of qubits. `compress`
    is deterministic, so it can be reused elsewhere.

    Parameters
    ----------
    circuit: iter[{Gate, Circuit}]
        Circuit to compress.
    max_qubits: int, optional
        Maximum number of qubits that a compressed gate may have.
    exclude_qubits: list[any], optional
        Exclude gates which act on `exclude_qubits` to be compressed.
    use_commutation: bool
        If `True`, use commutation to maximize compression.
    atol: float
        Absolute tollerance for commutation.
    verbose: bool, optional
        Verbose output.

    Returns
    -------
    list[Circuit]
        A list of `Circuit`s, with each `Circuit` representing a compressed
        `Gate`.

    See Also
    --------
    hybridq.gate.commutes_with

    Example
    -------
    >>> # Define circuit
    >>> circuit = Circuit(
    >>>     [Gate('X', qubits=[0])**1.2,
    >>>      Gate('ISWAP', qubits=[0, 1])**2.3,
    >>>      Gate('ISWAP', qubits=[0, 2])**2.3])
    >>>
    >>> # Compress circuit up to 1-qubit gates
    >>> utils.compress(circuit, 1)
    [Circuit([
        Gate(name=X, qubits=[0])**1.2
     ]),
     Circuit([
        Gate(name=ISWAP, qubits=[0, 1])**2.3
     ]),
     Circuit([
        Gate(name=ISWAP, qubits=[0, 2])**2.3
     ])]
    >>> # Compress circuit up to 2-qubit gates
    >>> utils.compress(circuit, 2)
    [Circuit([
        Gate(name=X, qubits=[0])**1.2
        Gate(name=ISWAP, qubits=[0, 1])**2.3
     ]),
     Circuit([
        Gate(name=ISWAP, qubits=[0, 2])**2.3
     ])]
    >>> # Compress circuit up to 3-qubit gates
    >>> utils.compress(circuit, 3)
    [Circuit([
        Gate(name=X, qubits=[0])**1.2
        Gate(name=ISWAP, qubits=[0, 1])**2.3
        Gate(name=ISWAP, qubits=[0, 2])**2.3
     ])]
    """

    # Initialize exclude_qubits
    exclude_qubits = set([] if exclude_qubits is None else exclude_qubits)

    # Initialize compressed circuit
    new_circuit = []

    # For every gate in circuit ..
    for gate in tqdm(circuit,
                     disable=not verbose,
                     desc=f'Compress ({max_qubits})'):
        # Convert to circuit
        _circ = Circuit([gate]) if isinstance(gate, Gate) else gate

        # Get unitary
        _gate = to_matrix_gate(_circ,
                               max_compress=0) if use_commutation else None

        # Get qubits
        _q = set(_gate.qubits if use_commutation else _circ.all_qubits())

        # Initialize index
        _merge_to = []

        # Check that no qubits are excluded
        if not exclude_qubits.intersection(_q):
            for i, (c, U) in reversed(list(enumerate(new_circuit))):
                # Get qubits
                _cq = c.all_qubits()

                # Check if it can be merged
                if not exclude_qubits.intersection(_cq) and len(
                        _q.union(_cq)) <= max_qubits:
                    _merge_to.append(i)

                # Check if commutes
                if not use_commutation or not _gate.commutes_with(U):
                    break

        # Merge to an existing cluster
        if _merge_to:
            _nc = new_circuit[min(_merge_to)]
            _nc[0].extend(_circ)
            _nc[1] = to_matrix_gate([_nc[1], _gate],
                                    max_compress=0) if use_commutation else None

        # Create new cluster
        else:
            new_circuit.append([_circ, _gate])

    # Return only circuits
    return [c for c, _ in new_circuit]


def unitary(circuit: iter[Gate],
            order: iter[any] = None,
            complex_type: any = 'complex64',
            max_compress: int = 4,
            verbose: bool = False) -> numpy.ndarray:
    """
    Return unitary matrix representing `circuit`.

    Parameters
    ----------
    circuit: iter[Gate]
        Circuit to get the unitary matrix from.
    order: iter[any], optional
        If specified, a unitary matrix is returned following the order given by
        `order`. Otherwise, `circuit.all_qubits()` is used.
    max_compress: int, optional
        To reduce the computational cost, `circuit` is compressed prior to
        compute the unitary matrix.
    complex_type: any, optional
        Complex type to use to compute the unitary matrix.
    verbose: bool, optional
        Verbose output.

    Returns
    -------
    numpy.ndarray
        Unitary matrix of `circuit`.

    Example
    -------
    >>> # Define circuit
    >>> circuit = Circuit([Gate('CX', [1, 0])])
    >>> # Show qubits
    [0, 1]
    >>> circuit.all_qubits()
    >>> # Get unitary without specifying any qubits order
    >>> # (therefore using circuit.all_qubits() == [0, 1])
    >>> utils.unitary()
    array([[1.+0.j, 0.+0.j, 0.+0.j, 0.+0.j],
           [0.+0.j, 0.+0.j, 0.+0.j, 1.+0.j],
           [0.+0.j, 0.+0.j, 1.+0.j, 0.+0.j],
           [0.+0.j, 1.+0.j, 0.+0.j, 0.+0.j]], dtype=complex64)
    >>> # Get unitary with a specific order of qubits
    >>> utils.unitary(Circuit([Gate('CX', [1, 0])]), order=[1, 0])
    array([[1.+0.j, 0.+0.j, 0.+0.j, 0.+0.j],
           [0.+0.j, 1.+0.j, 0.+0.j, 0.+0.j],
           [0.+0.j, 0.+0.j, 0.+0.j, 1.+0.j],
           [0.+0.j, 0.+0.j, 1.+0.j, 0.+0.j]], dtype=complex64)
    """

    # Convert iterable to Circuit
    circuit = Circuit(circuit)

    # Check order
    if order is not None:
        # Conver to list
        order = list(order)
        if set(order).difference(circuit.all_qubits()):
            raise ValueError(
                "'order' must be a valid permutation of indexes in 'Circuit'.")

    # Compress circuit
    if max_compress > 0:
        return unitary(Circuit(
            to_matrix_gate(c, complex_type=complex_type, max_compress=0)
            for c in compress(circuit, max_qubits=max_compress)),
                       order=order,
                       complex_type=complex_type,
                       max_compress=0,
                       verbose=verbose)

    # Get qubits
    qubits = circuit.all_qubits()
    n_qubits = len(qubits)

    # Initialize unitary
    U = np.reshape(np.eye(2**n_qubits),
                   [2] * (2 * n_qubits)).astype(complex_type)

    for g in tqdm(circuit, disable=not verbose):

        # Get gate's qubits
        _qubits = g.qubits
        _n_qubits = len(_qubits)

        # Get map
        _map = [qubits.index(q) for q in _qubits]
        _map += [x for x in range(n_qubits) if x not in _map]

        # Reorder qubits
        qubits = [qubits[x] for x in _map]

        # Update U
        U = np.reshape(
            g.unitary().astype(complex_type) @ np.reshape(
                np.transpose(U, _map + list(range(n_qubits, 2 * n_qubits))),
                (2**_n_qubits, 2**(2 * n_qubits - _n_qubits))),
            (2,) * (2 * n_qubits))

    # Get U
    U = np.reshape(
        np.transpose(U,
                     argsort(qubits) + list(range(n_qubits, 2 * n_qubits))),
        (2**n_qubits, 2**n_qubits))

    # Reorder if required
    if order and order != circuit.all_qubits():
        qubits = circuit.all_qubits()
        U = np.reshape(
            np.transpose(np.reshape(U, (2,) * (2 * n_qubits)),
                         [qubits.index(q) for q in order] +
                         [n_qubits + qubits.index(q) for q in order]),
            (2**n_qubits, 2**n_qubits))

    # Return unitary
    return U


def simplify(circuit: list[Gate],
             atol: float = 1e-8,
             use_commutation: bool = True,
             remove_id_gates: bool = True,
             verbose: bool = False) -> Circuit:
    """
    Compress together gates up to the specified number of qubits.
    """

    # Initialize new circuit
    new_circuit = Circuit()

    # Remove gates if required
    if remove_id_gates:
        rev_circuit = (g for g in reversed(circuit) if g.name != 'I')
    else:
        rev_circuit = reversed(circuit)

    # Insert gates, one by one
    for gate in tqdm(rev_circuit,
                     disable=not verbose,
                     total=len(circuit),
                     desc='Simplify'):
        insert_from_left(new_circuit,
                         gate,
                         atol=atol,
                         use_commutation=use_commutation,
                         simplify=True,
                         pop=False,
                         pinned_qubits=None,
                         inplace=True)

    # Return simplified circuit
    return new_circuit


def popright(circuit: list[Gate],
             pinned_qubits: list[any],
             atol: float = 1e-8,
             use_commutation: bool = True,
             simplify: bool = True,
             verbose: bool = False) -> Circuit:
    """
  Remove gates outside the lightcone created by pinned_qubits.
  """

    # Initialize new circuit
    new_circuit = Circuit()

    # Insert gates, one by one
    for gate in tqdm(reversed(circuit),
                     disable=not verbose,
                     total=len(circuit),
                     desc='Pop'):
        insert_from_left(new_circuit,
                         gate,
                         atol=atol,
                         use_commutation=use_commutation,
                         simplify=simplify,
                         pop=True,
                         pinned_qubits=pinned_qubits,
                         inplace=True)

    # Return simplified circuit
    return new_circuit


def popleft(circuit: list[Gate],
            pinned_qubits: list[any],
            atol: float = 1e-8,
            use_commutation: bool = True,
            simplify: bool = True,
            verbose: bool = False) -> Circuit:
    """
  Remove gates outside the lightcone created by pinned_qubits (starting from the right).
  """

    return Circuit(
        reversed(
            popright(list(reversed(circuit)),
                     pinned_qubits=pinned_qubits,
                     atol=atol,
                     use_commutation=use_commutation,
                     simplify=simplify,
                     verbose=verbose)))


def pop(circuit: list[Gate],
        direction: str,
        pinned_qubits: list[any],
        atol: float = 1e-8,
        use_commutation: bool = True,
        simplify: bool = True,
        verbose: bool = False) -> Circuit:
    """
    Remove gates outside the lightcone created by pinned_qubits.
    """

    _popleft = partial_func(popleft,
                            pinned_qubits=pinned_qubits,
                            atol=atol,
                            use_commutation=use_commutation,
                            simplify=simplify,
                            verbose=verbose)
    _popright = partial_func(popright,
                             pinned_qubits=pinned_qubits,
                             atol=atol,
                             use_commutation=use_commutation,
                             simplify=simplify,
                             verbose=verbose)

    if direction == 'left':
        return _popleft(circuit)
    elif direction == 'right':
        return _popright(circuit)
    elif direction == 'both':
        return _popleft(_popright(circuit))
    else:
        raise ValueError(f"direction='{direction}' not supported.")


def moments(circuit: iter[Gate]) -> list[list[Gate]]:
    """
    Split circuit in moments.
    """

    # Convert iterable to Circuit
    circuit = Circuit(circuit)

    # Get qubits
    qubits = sort({q for gate in circuit for q in gate.qubits})

    level_map = {q: 0 for q in qubits}
    level = [0] * len(circuit)

    for i, gate in enumerate(circuit):

        # Get max level
        level[i] = np.max([level_map[q] for q in gate.qubits]) + 1

        # Update level_map
        level_map.update({q: level[i] for q in gate.qubits})

    circuits = [Circuit() for _ in range(np.max(level))]

    for i, gate in enumerate(circuit):
        circuits[level[i] - 1].append(gate)

    return circuits


def kron(*arrays):
    """
    Compute multiple kron.
    """
    out = arrays[0]
    for array in arrays[1:]:
        out = np.kron(out, array)

    return out


def remove_swap(circuit: Circuit) -> tuple[Circuit, dict[any, any]]:
    """
    Iteratively remove SWAP's from circuit by actually swapping qubits.
    The output map will have the form new_qubit -> old_qubit.
    """

    # Initialize map
    _qubits_map = {q: q for q in circuit.all_qubits()}

    # Initialize circuit
    _circ = Circuit()

    for gate in circuit:

        if gate.name == 'SWAP':

            # Swap qubits
            _q0 = next(k for k, v in _qubits_map.items() if v == gate.qubits[0])
            _q1 = next(k for k, v in _qubits_map.items() if v == gate.qubits[1])
            _qubits_map[_q0], _qubits_map[_q1] = _qubits_map[_q1], _qubits_map[
                _q0]

        else:

            # Get the right qubits
            _qubits = [
                next(k
                     for k, v in _qubits_map.items()
                     if v == q)
                for q in gate.qubits
            ]

            # Append to the new circuit
            _circ.append(gate.on(_qubits))

    # Return circuit and map
    return _circ, _qubits_map


def expand_iswap(circuit: Circuit) -> Circuit:
    """
    Expand ISWAP's by iteratively replacing with SWAP's, CZ's and Phases.
    """

    _circ = Circuit()
    for gate in circuit:
        if gate.name == 'ISWAP' and (gate.power == 1 or gate.power == -1):
            _tags = gate.tags if hasattr(gate, 'tags') else {}
            _ext = [
                Gate('SWAP', qubits=gate.qubits, tags=_tags),
                Gate('CZ', qubits=gate.qubits, tags=_tags),
                Gate('P', qubits=[gate.qubits[0]], tags=_tags),
                Gate('P', qubits=[gate.qubits[1]], tags=_tags),
            ]

            if gate.power == 1:
                _circ.extend(_ext)
            else:
                _circ.extend(gate**-1 for gate in reversed(_ext))
        else:
            _circ.append(deepcopy(gate))

    return _circ


def filter(circuit: iter,
           names: list[str] = any,
           qubits: list[any] = any,
           params: list[any] = any,
           n_qubits: int = any,
           n_params: int = any,
           virtual: bool = any,
           exact_match: bool = False,
           atol: float = 1e-8,
           **kwargs) -> iter:

    # Initialize
    f_circuit = iter(circuit)

    # Filter by name
    if names is not any:
        names = {str(name).upper() for name in names}
        f_circuit = (gate for gate in f_circuit if gate.name in names)

    # Filter by qubits
    if qubits is not any:
        if exact_match:
            qubits = list(qubits)
            f_circuit = (gate for gate in f_circuit
                         if hasattr(gate, 'qubits') and gate.qubits == qubits)
        else:
            qubits = set(qubits)
            f_circuit = (
                gate for gate in f_circuit
                if hasattr(gate, 'qubits') and qubits.intersection(gate.qubits))

    # Filter by parameters
    if params is not any:
        f_circuit = (
            gate for gate in f_circuit
            if hasattr(gate, 'params') and np.allclose(
                [float(p) for p in gate.params], [float(p) for p in params],
                atol=atol))

    # Filter by number of qubits
    if n_qubits is not any:

        def _filter(gate):
            return (n_qubits == 0 and not hasattr(gate, 'qubits')) or (hasattr(
                gate, 'qubits') and len(gate.qubits) == n_qubits)

        f_circuit = (gate for gate in f_circuit if _filter(gate))

    # Filter by number of parameters
    if n_params is not any:

        def _filter(gate):
            return (n_params == 0 and not hasattr(gate, 'params')) or (hasattr(
                gate, 'params') and len(gate.params) == n_params)

        f_circuit = (gate for gate in f_circuit if _filter(gate))

    # Filter virtual gates
    if virtual is not any:
        f_circuit = (gate for gate in f_circuit if gate.isvirtual() == virtual)

    # Filter by tags
    for k, v in kwargs.items():

        # Define filter
        if exact_match:

            def _filter(gate):
                if hasattr(gate, 'tags'):
                    for k, v in kwargs.items():
                        if k not in gate.tags or (v is not any and
                                                  gate.tags[k] != v):
                            return False
                    return True
                else:
                    return False
        else:

            def _filter(gate):
                if hasattr(gate, 'tags'):
                    for k, v in kwargs.items():
                        if k in gate.tags and (v is any or gate.tags[k] == v):
                            return True
                    return False
                else:
                    return False

        f_circuit = (gate for gate in f_circuit if _filter(gate))

    return f_circuit

"""
Author: Salvatore Mandra (salvatore.mandra@nasa.gov)

Copyright © 2021, United States Government, as represented by the Administrator
of the National Aeronautics and Space Administration. All rights reserved.

The HybridQ: A Hybrid Simulator for Quantum Circuits platform is licensed under
the Apache License, Version 2.0 (the "License"); you may not use this file
except in compliance with the License. You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0.

Unless required by applicable law or agreed to in writing, software distributed
under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from __future__ import annotations
import numpy as np
import scipy as sp


def _type(x):
    try:
        float(x)
        return float
    except:
        return type(x)


def argsort(x: iter[any], key=None, reverse: bool = False) -> list[any]:
    """
    Argsort heterogeneous list.
    """

    _s = [
        i for _, i in sorted(map(lambda x: ((str(_type(x[1])), x[1]), x[0]),
                                 enumerate(map(key, x) if key else x)),
                             key=lambda x: x[0])
    ]

    return list(reversed(_s)) if reverse else _s


def sort(x: iter[any], key=None, reverse: bool = False) -> list[any]:
    """
    Sort heterogeneous list.
    """

    if key:
        _s = [
            x for _, x in sorted(map(lambda x: ((str(_type(x[0])), x[0]), x[1]),
                                     map(lambda x: (key(x), x), x)),
                                 key=lambda x: x[0])
        ]
    else:
        _s = [x for _, x in sorted(map(lambda x: (str(_type(x)), x), x))]

    return list(reversed(_s)) if reverse else _s


def svd(U,
        first_half: list[any],
        sort: bool = False,
        atol: float = 1e-6,
        **kwargs):
    """
    Return SVD of a given matrix.

    Returns
    -------
    s, uh, vh:
        `s` are the weights and rows of `uh` and `vh` contain the left/right decomposition.
    """

    # Get number of qubits
    n_qubits = int(np.log2(len(U)))
    n_qubits_l = len(first_half)
    n_qubits_r = n_qubits - n_qubits_l

    if n_qubits != np.log2(len(U)):
        raise ValueError("'U' must be a square matrix of (2**n, 2**n)"
                         "elements, with n the number of qubits")

    if any(q >= n_qubits for q in first_half):
        raise ValueError("All indexes in 'first_half' must be"
                         "smaller than the number of qubits.")

    # Get qubits
    qubits = list(range(n_qubits))
    qubits_l = np.array([qubits.index(q) for q in first_half])
    qubits_r = np.array(
        [x for x, q in enumerate(qubits) if q not in first_half])

    # Few Checks
    assert (n_qubits_l == len(qubits_l))
    assert (n_qubits_r == len(qubits_r))

    # Get new order of axes
    order = np.concatenate(
        [qubits_l, qubits_l + n_qubits, qubits_r,
         qubits_r + n_qubits]).astype('int').tolist()

    # Reshape U
    _U = np.reshape(np.transpose(np.reshape(U, (2,) * (2 * n_qubits)), order),
                    (2**(2 * n_qubits_l), 2**(2 * n_qubits_r)))

    # SVD
    u, s, vh = sp.linalg.svd(_U, full_matrices=False, **kwargs)

    # Transpose u
    uh = u.T
    del (u)

    # Remove all weights below atol
    if atol:
        _sel = np.abs(s) >= atol
        s, uh, vh = s[_sel], uh[_sel], vh[_sel]

    if sort:
        _sel = np.argsort(s)
        s, uh, vh = s[_sel], uh[_sel], vh[_sel]

    # Reshape
    uh = np.reshape(uh, (len(s), 2**n_qubits_l, 2**n_qubits_l))
    vh = np.reshape(vh, (len(s), 2**n_qubits_r, 2**n_qubits_r))

    # Find order for W
    # W_order = first_half + [q for q in qubits if q not in first_half]
    # W_order += [q + n_qubits for q in W_order]
    # W_order = [W_order.index(q) for q in range(2 * n_qubits)]
    # #
    # W = sum(s[i] * np.kron(uh[i], vh[i]) for i in range(len(s)))
    # W = np.reshape(
    #     np.transpose(np.reshape(W, (2, ) * (2 * n_qubits)), W_order),
    #     (2**n_qubits, 2**n_qubits))
    # #
    # assert (np.allclose(W, U, atol=1e-5))

    return s, uh, vh
